package org.itstep.polimorphismdemo;

public interface List {
    int START_SIZE = 2;
    public abstract void add(int item); // добавление нового элемента в список
    int get(int idx); // получение элемента по индексу
    int size();
    boolean empty();
}

class ArrayList implements List {

    private int idx = -1;
    private int[] arr = new int[START_SIZE];

    @Override
    public void add(int item) {
        if(size() >= arr.length) {
            int[] tmp = new int[arr.length*2];
            System.arraycopy(arr, 0, tmp, 0, arr.length);
            arr = tmp;
        }
        arr[++idx] = item;
    }

    @Override
    public int get(int idx) {
        return arr[idx];
    }

    @Override
    public int size() {
        return idx+1;
    }

    @Override
    public boolean empty() {
        return idx == -1;
    }
}
