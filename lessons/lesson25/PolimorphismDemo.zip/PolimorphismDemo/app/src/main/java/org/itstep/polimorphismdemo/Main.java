package org.itstep.polimorphismdemo;

import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //Animal animal = new Animal();
        //Mammal mammal = new Mammal();
//        Rabbit rabbit = new Rabbit();
//        rabbit.jump();
//        rabbit.test();

        ArrayList arrayList = new ArrayList();

        Random rnd = new Random();
        for(int i=0; i<20; i++) {
            arrayList.add(rnd.nextInt(100));
        }
        for(int i=0; i<arrayList.size(); i++) {
            System.out.print(arrayList.get(i) + ", ");
        }
        System.out.println();
    }
}

abstract class Animal {
    public Animal() {
        System.out.println("Animal");
    }

    public void test() {
        System.out.println("test");
    }
    public abstract void jump();
}

abstract class Mammal extends Animal {
    public Mammal() {
        System.out.println("Mammal");
    }
}

class Rabbit extends Mammal {
    public Rabbit() {
        System.out.println("Rabbit");
    }

    @Override
    public void jump() {
        System.out.println("Jump up to 5 m");
    }
}
