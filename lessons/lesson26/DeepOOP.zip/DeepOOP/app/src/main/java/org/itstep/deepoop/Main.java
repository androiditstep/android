package org.itstep.deepoop;

import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {

//        Animal animal = new Animal();
        whoAreYou(new Dog());
        whoAreYou(new Dingo());
    }

    private static void whoAreYou(Object obj) {
        Class cls = obj.getClass();
        System.out.println("Name: " + cls.getName());
        System.out.println("Simple name: " + cls.getSimpleName());

        if(obj instanceof Dog) {
            Dog dog = (Dog) obj;
            dog.bark();
        }
        Implementation implementation = new Implementation();
        implementation.test();
    }
}

//class MyString extends String {
//
//}

interface Interface {
    default void test() {
        System.out.println("test");
    }
}

class Implementation implements Interface {

}

abstract class Animal extends Object {


    final String getName() {
        return "Animal";
    }
}

class Dog extends Animal {
    void bark() {
        System.out.println("bark");
    }

//    @Override
//    String getName() {
//        return "Dog";
//    }
}

class Dingo extends Dog {

}

class Cat extends Animal {

}
