package org.itstep.nestedclasses;

public class App {

    public static void main(String[] args) {
//        Man.Hat redHat = new Man.Hat("Red");
//
//        Man man = new Man("Вася", 125);
//        Man.Heart heart = man.new Heart();
        LinkedList list = new LinkedList();
        list.pushBack(5);
        list.pushBack(10);
        list.pushBack(21);
        list.pushBack(100);

        System.out.println(list);
        list.deleteFront();

        System.out.println(list.get(2));
        System.out.println(list.get(0));
        System.out.println(list);
        list.insert(1, 50);
        System.out.println(list);
        list.insert(3, 5);
        System.out.println(list);
    }
}

class LinkedList {
    private class Node {
        Object data;
        Node next;

        public Node(Object data) {
            this.data = data;
        }
    }

    private Node head;
    private Node tail;

    public void pushBack(Object data) {
        if(head == null) { // это первый элемент
            addFirst(data);
        } else {
            Node newNode = new Node(data);
            tail.next = newNode;
            tail = newNode;
        }
    }

    private void addFirst(Object data) {
        Node node = new Node(data);
        head = node;
        tail = head;
    }

    public void pushFront(Object data) {
        if(head == null) { // это первый элемент
            addFirst(data);
        } else {
            // FIXME: Добавить первый элемент списка
        }
    }

    public void deleteFront() {
        if(head != null) {
            head = head.next;
        }
    }

    public void deleteBack() {
        // FIXME: Удалить последний элемент массива
    }

    /**
     * Возвратить элемент по индексу
     * @param i
     * @return
     */
    public Object get(int i) {
        Node node = findNode(i);
        if(node != null) {
            return node.data;
        }
        return null;
    }

    private Node findNode(int i) {
        Node cur = head;
        int count = 0;
        while (cur != null) {
            if(count == i) {
                return cur;
            }
            cur = cur.next;
            count++;
        }
        return null;
    }

    public void insert(int i, Object data) {
        if(i == 0) {
            addFirst(data);
        } else {
            Node cur = findNode(i-1);
            if(cur != null) {
                Node newNode = new Node(data);
                newNode.next = cur.next;
                cur.next = newNode;
            }
        }
    }

    public void delete(int i) {
        // FIXME: удалить элемент по индексу
    }

    @Override
    public String toString() {
        Node cur = head;
        String str = "";
        while (cur != null) {
            str += cur.data + " ";
            cur = cur.next;
        }

        return str;
    }
}

class Man {
    String name;
    int age;
    private static int count;

    static class Hat {
//        static int count;
        String color;

        public Hat(String color) {
            this.color = color;
//            name = "Вася";
//            count = 10;
        }
    }

    class Heart {
        public Heart() {
            System.out.println("Name: " + name);
            System.out.println("Age: " + age);
        }
    }

    Heart heart;

    public Man(String name, int age) {
        this.name = name;
        this.age = age;
        heart = new Heart();
    }
}
