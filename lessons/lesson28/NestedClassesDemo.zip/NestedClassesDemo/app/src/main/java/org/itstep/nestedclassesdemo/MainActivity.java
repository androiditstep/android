package org.itstep.nestedclassesdemo;

import android.app.Activity;
import android.os.Bundle;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Comparator;

public class MainActivity {

    static InputStream in;

    static {
        try {
            in = new FileInputStream("test");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public Comparator cmp = new Comparator() {
        @Override
        public int compare(Object o1, Object o2) {
            return 0;
        }
    };

    public static void main(String[] args) {
        Unit unit1 = UnitCreator.create(UnitName.WARRIOR);
        unit1.attack();
        unit1.defend();

        Unit unit2 = UnitCreator.create(UnitName.HORSEMAN);
        unit2.attack();
        unit2.defend();

        Integer[] arr = {2, 3, 1, 4, 8, 9, 0};

        Arrays.sort(arr, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                return ((Integer) o2) - ((Integer) o1);
            }
        });
        System.out.println(Arrays.toString(arr));

        Test.action(new Action() {

            {
                System.out.println("Init anonymous class");
            }

            @Override
            public void doIt() {
                System.out.println("do it");
            }
        });
    }
}

interface Action {
    void doIt();
}
class Test {
    public static void action(Action action) {
        action.doIt();
    }
}

abstract class Unit {

    private String name;

    public Unit(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public abstract void attack();

    public abstract void defend();
}

enum UnitName {
    WARRIOR, HORSEMAN
}

class UnitCreator {

    private static int test = 0;

    public static Unit create(UnitName name) {
        Unit unit = null;
        final int i = 0;

        class HorseMan extends Unit {

            {
                System.out.println("Init HorseMan class");
            }

            public HorseMan() {
                super("HorseMan");
                System.out.println(i);
                test = 100;
            }

            {
                System.out.println("Other init block");
            }

            @Override
            public void attack() {
                System.out.println(getName() + " attack +10");
            }

            @Override
            public void defend() {
                System.out.println(getName() + " defend -5");
            }
        }

        Unit warrior = new Unit("Warrior") {

            @Override
            public void attack() {
                System.out.println(getName() + " attack +5");
            }

            @Override
            public void defend() {
                System.out.println(getName() + " defend -7");
            }
        };

        switch (name) {
            case WARRIOR:
                unit = warrior;
                break;
            case HORSEMAN:
                unit = new HorseMan();
                break;
            default:
                break;
        }

        return unit;
    }

}

