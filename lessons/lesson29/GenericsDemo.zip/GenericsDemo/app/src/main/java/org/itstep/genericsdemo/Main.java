package org.itstep.genericsdemo;

import android.app.Activity;
import android.os.Bundle;

public class Main {

    public static void main(String[] args) {

        Tea tea = new Tea("Черный");

        Jar<Tea> jar = new Jar<>();
        jar.setValue(tea);

        Jar<Coffee> coffeeJar = new Jar<>();
        coffeeJar.setValue(new Coffee("Бразильский кофе"));

        ///

//        Object value =  jar.getValue();
//        if(value instanceof Coffee) {
//            System.out.println("Завариваю " + ((Coffee)(value)).getName());
//        }
        System.out.println(jar.getValue().getName());
        System.out.println(coffeeJar.getValue().getName());

        Jar<Integer> intJar = new Jar<>();
        intJar.setValue(1);

        Jar objJar = new Jar(); // raw type
        objJar.setValue(tea);
        Tea t = (Tea) objJar.getValue();

        Integer i = 10; // упаковка
        int n = i; // распаковка


    }
}

class Jar<T> {
    T value;

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }
}

class JarTea {
    Tea value;

    public Tea getValue() {
        return value;
    }

    public void setValue(Tea value) {
        this.value = value;
    }
}

class JarCoffee {
    Coffee value;

    public Coffee getValue() {
        return value;
    }

    public void setValue(Coffee value) {
        this.value = value;
    }
}

class Tea {
    String name;

    public Tea(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}


class Coffee {
    String name;

    public Coffee(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

