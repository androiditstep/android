package org.itstep.genericsandexceptions;

public class Main {

    static class Drink {
        String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    static class Tea extends Drink {
        @Override
        public String toString() {
            return "Tea";
        }
    }

    static class Cat {

    }

    static class Coffee extends Drink {
        @Override
        public String toString() {
            return "Coffee";
        }
    }

    static class Box<T> {
        T value;

        public T getValue() {
            return value;
        }

        public void setValue(T value) {
            this.value = value;
        }
    }

    static void printBoxContent(Box<?> objectBox) {
        System.out.println(objectBox.getValue());
    }

    static void printDrinkName(Box<? extends Drink> drinkBox) {
        Drink drink = drinkBox.getValue();
        System.out.println(drink.getName());
    }

    static void putDrinkIntoBox(Box<? super Drink> drinkBox, Drink drink) {
        drinkBox.setValue(drink);
    }

    public static void main(String[] args) {
        Box<Tea> teaBox = new Box<>();
        Tea tea = new Tea();
        tea.setName("Black tea");
        teaBox.setValue(tea);

        printBoxContent(teaBox);
        printDrinkName(teaBox);

        Box<Coffee> coffeeBox = new Box<>();
        Coffee coffee = new Coffee();
        coffee.setName("Brazilian coffee");
        coffeeBox.setValue(coffee);

        printBoxContent(coffeeBox);
        printDrinkName(coffeeBox);

        Box<Cat> catBox = new Box<>();
        catBox.setValue(new Cat());
        //....
        //...
//        printDrinkName(catBox);
        Box<Drink> drinkBox = new Box<>();
        putDrinkIntoBox(drinkBox, new Tea());
    }

}


