package org.itstep.genericsandexceptions;

public class Practice {
    public static void main(String[] args) {
        List<Integer> arrayList = new ArrayList<>();
        arrayList.add(1);
        arrayList.add(2);
        arrayList.add(3);
        arrayList.add(4); // 1 2 3 4

        List<Integer> arrayList2 = new ArrayList<>();
        arrayList2.add(-1);
        arrayList2.add(0);
        arrayList2.addAll(arrayList); // получаем объедененный списко: 0 -1 1 2 3 4  (arrayList2 + arrayList)

        //arrayList2.removaAll(arrayList); // получаем список: 0 -1 (arrayList2 - arrayList)

        //int sum = arrayList.sum(arrayList2); // 0 + -1 + 1 + 2 + 3 + 4
    }
}

interface List<T> {
    int START_SIZE = 10;
    void add(T item); // добавление нового элемента в список
    T get(int idx); // получение элемента по индексу
    int size();
    boolean empty();

    void addAll(List<T> arrayList);
}

/**
 * 1. Создать обобщенный ArrayList, работаем только с классами производными от Number
 * 2. Добавить метод addAll(ArrayList)
 * 3. Добавить метод removeAll(ArrayList)
 * 4. Получить сумму всех чисел реаилзовав метод sum(ArrayList)
 */

class ArrayList<T extends Number> implements List<T> {

    private int idx = -1;
    private Number[] arr = new Number[START_SIZE];


    @Override
    public void add(T item) {
        if(size() >= arr.length) {
            Number[] tmp = new Number[arr.length*2];
            System.arraycopy(arr, 0, tmp, 0, arr.length);
            arr = tmp;
        }
        arr[++idx] = item;
    }

    @Override
    public T get(int idx) {
        return (T)arr[idx];
    }

    @Override
    public int size() {
        return idx+1;
    }

    @Override
    public boolean empty() {
        return idx == -1;
    }

    @Override
    public void addAll(List<T> other) {
        for(int i=0; i<other.size(); i++) {
            this.add(other.get(i));
        }
    }
}
