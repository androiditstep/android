package org.itstep.exceptiondemo;

import android.app.Activity;
import android.os.Bundle;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static int div(int a, int b) throws DivisionByZeroException {

        if(b == 0) {
            throw new DivisionByZeroException("Деление на ноль");
        }

        return a / b;
    }

    public static void main(String[] args) {
        int num = 10;

        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите делитель: ");
        try {
            int den = scanner.nextInt();
            System.out.println(div(num, den));
            throw new RuntimeException("Мое исключение");
        } catch (InputMismatchException ex) {
            System.out.println("Ошибка ввода данных. Че ты ввел?");
//        } catch (ArithmeticException ex) {
//            System.out.println("Ошибка: " + ex.getLocalizedMessage());
//            //ex.printStackTrace();
        } catch (DivisionByZeroException e) {
            System.out.println(e.getClass());
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Конец работы программы");
        }
    }
}

class DivisionByZeroException extends Exception {
    public DivisionByZeroException(String message) {
        super(message);
    }
}
