package org.itstep.jcf;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

public class Main {
    public static void main(String[] args) {
//        Collection<String> collection = new ArrayList<>();
//        collection.add("one");
//        collection.add("two");
//        collection.add("three");
//        collection.add("four");
//
//        Iterator<String> iterator = collection.iterator();
//        while (iterator.hasNext()) {
//            System.out.println(iterator.next());
//        }
//        for(String item: collection) {
//            System.out.println(item);
//        }
//        System.out.println("-----------");
//        collection = new HashSet<>();
//        collection.add("one");
//        collection.add("two");
//        collection.add("three");
//        collection.add("four");
//        for(String item: collection) {
//            System.out.println(item);
//        }

        MyHashMap<String, String> map = new MyHashMap<>();
        long start = System.currentTimeMillis();
        map.put("one", "two");
        map.put("three", "two");
        map.put("four", "two");
        map.put("four", "five");
        long end = System.currentTimeMillis();
        System.out.println(end-start);

        System.out.println(map.get("one"));
    }
}

class MyHashMap<K, V> {

    Node<K, V>[] hashMap = new Node[2];

    static class Node<K, V> {
        K key;
        V value;
        Node<K, V> next;

        public Node(K key, V value, Node<K, V> next) {
            this.key = key;
            this.value = value;
            this.next = next;
        }
    }

    V get(K key) {
        V value = null;
        int hash = key.hashCode();
        int idx = hash % hashMap.length;

        Node<K, V> node = hashMap[idx];
        while (node != null) {
            if(node.key.equals(key)) {
                value = node.value;
                break;
            }
            node = node.next;
        }

        return value;
    }

    void put(K key, V value) {
        int hash = key.hashCode();
        System.out.println(key + ":" + hash);
        Node<K, V> node = new Node<>(key, value, null);
        int idx = hash % hashMap.length;
        if (hashMap[idx] == null) {
            hashMap[idx] = node;
        } else {
            Node<K, V> head = hashMap[idx];
            while (head != null) {
                if (head.key.equals(key)) {
                    head.value = value;
                    break;
                }
                if (head.next == null) {
                    head.next = node;
                }
                head = head.next;
            }
        }
    }
}
