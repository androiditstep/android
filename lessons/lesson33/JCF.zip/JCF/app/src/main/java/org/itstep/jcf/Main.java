package org.itstep.jcf;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;


public class Main {
    @RequiresApi(api = Build.VERSION_CODES.N)
    public static void main(String[] args) {

        Collection<String> collection = new HashSet<>();
        collection.add("One");
        collection.add("Two");
        collection.add("Two");
        collection.add("Three");
        collection.add("Three");
        collection.add("Three");
        collection.add("Four");
        collection.add("Four");
        collection.add("Four");
        collection.add("Four");
        collection.add("Five");
        collection.add("Five");
        collection.add("Five");
        collection.add("Five");
        collection.add("Five");

        for(String s: collection) {
            System.out.println(s);
        }

        Collection<Car> garage = new TreeSet<>();
        garage.add(new Car("Mersedes", 4));
        garage.add(new Car("BMW", 10));
        garage.add(new Car("Lamborginy", 1));
        garage.add(new Car("Mersedes", 5));
        for(Car c: garage) {
            System.out.println(c);
        }
        System.out.println("----------");
        Map<String, Car> garageMap = new TreeMap<>(new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return o2.compareTo(o1);
            }
        });
        garageMap.put("b", new Car("Mercedes", 3));
        garageMap.put("a", new Car("Audi", 2));
        garageMap.putIfAbsent("a", new Car("ZAZ", 2));
        garageMap.put("c", new Car("Opel", 1));

        for(Car c: garageMap.values()) {
            System.out.println(c);
        }
        System.out.println("----------");
        for(String k: garageMap.keySet()) {
            System.out.println(k+": " + garageMap.get(k));
        }
        System.out.println("----------");
        for(Map.Entry<String, Car> entry: garageMap.entrySet()) {
            System.out.println(entry.getKey()+": " + entry.getValue());
        }

    }
}

class Car implements Comparable<Car> {
    private String model;
    private int price;

    public Car(String model, int price) {
        this.model = model;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Car{" +
                "model='" + model + '\'' +
                ", price=" + price +
                '}';
    }

    @Override
    public int compareTo(@NonNull Car o) {
        return price - o.price;
    }

    @Override
    public boolean equals(Object obj) {
        boolean areEquals = false;
        if(obj instanceof Car) {
            Car other = (Car) obj;
            areEquals = model.equals(other.model);
        }
        return areEquals;
    }

    @Override
    public int hashCode() {
        return model.hashCode();
    }
}

class MyHashMap<K, V> {

    Node<K, V>[] hashMap = new Node[2];

    static class Node<K, V> {
        K key;
        V value;
        Node<K, V> next;

        public Node(K key, V value, Node<K, V> next) {
            this.key = key;
            this.value = value;
            this.next = next;
        }
    }

    V get(K key) {
        V value = null;
        int hash = key.hashCode();
        int idx = hash % hashMap.length;

        Node<K, V> node = hashMap[idx];
        while (node != null) {
            if(node.key.equals(key)) {
                value = node.value;
                break;
            }
            node = node.next;
        }

        return value;
    }

    void put(K key, V value) {
        int hash = key.hashCode();
        System.out.println(key + ":" + hash);
        Node<K, V> node = new Node<>(key, value, null);
        int idx = hash % hashMap.length;
        if (hashMap[idx] == null) {
            hashMap[idx] = node;
        } else {
            Node<K, V> head = hashMap[idx];
            while (head != null) {
                if (head.key.equals(key)) {
                    head.value = value;
                    break;
                }
                if (head.next == null) {
                    head.next = node;
                }
                head = head.next;
            }
        }
    }
}
