package org.itstep.binarytreedemo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.TreeSet;

public class Main {
    static int field;

    static {
        field = 0;
    }

    static int sum(int... args) {
        int s = 0;
        for (int i = 0; i < args.length; i++) {
            s += args[i];
        }
        return s;
    }

    public static void main(String[] args) {
        System.out.println(sum(1, 2, 3, 4, 5, 5, 5, 5, 5, 5, 5, 5));
        //demo();
        final int SIZE = 10;
        for (int i = 1; i <= 4; i++) {
            System.out.println((int) (SIZE * Math.pow(10, i)));
            ListBenchmark arrayListBenchmark = new ListBenchmark(new ArrayList<Integer>());
            arrayListBenchmark.init((int) (SIZE * Math.pow(10, i)));
            System.out.println("ArrayList random get by index test: " + arrayListBenchmark.testRandomGet());
            System.out.println("ArrayList random get by value test: " + arrayListBenchmark.testRandomFindValue());
            System.out.println("ArrayList remove all test: " + arrayListBenchmark.testRemoveAll());

            ListBenchmark linkedListBenchmark = new ListBenchmark(new LinkedList<Integer>());
            linkedListBenchmark.init((int) (SIZE * Math.pow(10, i)));
            System.out.println("LinkedList random get by index test: " + linkedListBenchmark.testRandomGet());
            System.out.println("LinkedList random get by value test: " + linkedListBenchmark.testRandomFindValue());
            System.out.println("LinkedList remove all test: " + linkedListBenchmark.testRemoveAll());

            ListBenchmark hashSetBenchmark = new ListBenchmark(new HashSet<Integer>());
            hashSetBenchmark.init((int) (SIZE * Math.pow(10, i)));
            System.out.println("HashSet random get by value test: " + hashSetBenchmark.testRandomFindValue());
            System.out.println("HashSet remove all test: " + hashSetBenchmark.testRemoveAll());

            ListBenchmark treeSetBenchmark = new ListBenchmark(new TreeSet<Integer>());
            treeSetBenchmark.init((int) (SIZE * Math.pow(10, i)));
            System.out.println("TreeSet random get by value test: " + treeSetBenchmark.testRandomFindValue());
            System.out.println("TreeSet remove all test: " + treeSetBenchmark.testRemoveAll());
        }
    }

    static class ListBenchmark {
        Collection<Integer> list;
        Random random = new Random();

        public ListBenchmark(Collection<Integer> list) {
            this.list = list;
        }

        public void init(int size) {
            for (int i = 0; i < size; i++) {
                list.add(i);
            }
        }

        public long testRemoveAll() {
            long start = System.currentTimeMillis();
            removeAllTop();
            long end = System.currentTimeMillis();
            return end - start;
        }

        public long testRandomGet() {
            long start = System.currentTimeMillis();
            randomFindByIndex();
            long end = System.currentTimeMillis();
            return end - start;
        }

        public long testRandomFindValue() {
            long start = System.currentTimeMillis();
            randomFindByValue();
            long end = System.currentTimeMillis();
            return end - start;
        }

        private void randomFindByValue() {
            for (int i = 0; i < list.size(); i++) {
                list.contains(random.nextInt(list.size()));
            }
        }

        private void randomFindByIndex() {
            if (list instanceof List) {
                for (int i = 0; i < list.size(); i++) {
                    Object item = ((List<Integer>) list).get(random.nextInt(list.size()));
                }
            }
        }

        private void removeAllTop() {
            for (int i = 0; i < list.size(); i++) {
                list.remove(i);
            }
        }
    }

    private static void demo() {
        List<Person> people = new ArrayList<>();
        Person p1 = new Person("Вася", 21);
        Person p2 = new Person("Вася", 21);
        people.add(p1);
        System.out.println(people.contains(p2));
    }

    private static class Person {
        String name;
        int age;

        public Person(String name, int age) {
            this.name = name;
            this.age = age;
        }

        @Override
        public int hashCode() {
            return name.hashCode() + age;
        }

        @Override
        public boolean equals(Object obj) {
            Person other;
            if (obj instanceof Person) {
                other = (Person) obj;
            } else {
                return false;
            }
            return name.equals(other.name) && age == other.age;
        }
    }
}
