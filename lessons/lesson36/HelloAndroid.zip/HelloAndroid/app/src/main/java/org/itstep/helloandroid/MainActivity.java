package org.itstep.helloandroid;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
//        LinearLayout linearLayout = new LinearLayout(this);
//        linearLayout.setOrientation(LinearLayout.VERTICAL);
//        LinearLayout.LayoutParams layoutParams =
//                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
//                                              ViewGroup.LayoutParams.MATCH_PARENT);
//        linearLayout.setLayoutParams(layoutParams);
//
//        TextView textView = new TextView(this);
//        LinearLayout.LayoutParams childParams =
//                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
//                        ViewGroup.LayoutParams.WRAP_CONTENT);
//        textView.setText("Hello World");
//        textView.setLayoutParams(childParams);
//        linearLayout.addView(textView);
//
//        Button button = new Button(this);
//        button.setLayoutParams(childParams);
//        button.setText("Click me");
//        linearLayout.addView(button);
//        setContentView(linearLayout);

    }
}
