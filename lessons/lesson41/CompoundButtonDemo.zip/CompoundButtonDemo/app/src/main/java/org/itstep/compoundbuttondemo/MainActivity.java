package org.itstep.compoundbuttondemo;

import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextInputLayout textInputLayout = findViewById(R.id.text_input_layout_login);
        EditText editText = findViewById(R.id.editText); //textInputLayout.getEditText();
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Log.i(TAG, "onTextChanged: ");
                textInputLayout.setErrorEnabled(false);
                textInputLayout.setError("");
                if("error".contentEquals(s)) {
                    Log.i(TAG, "onTextChanged: Error");
                    textInputLayout.setErrorEnabled(true);
                    textInputLayout.setError("You write error!");
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        EditText test = findViewById(R.id.test);
        test.setFilters(new InputFilter[]{
                new InputFilter() {
                    @Override
                    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                        Log.i(TAG, "filter: source: " + source);
                        Log.i(TAG, "filter: start: " + start);
                        Log.i(TAG, "filter: end: " + end);
                        Log.i(TAG, "filter: dest: " + dest);
                        Log.i(TAG, "filter: dstart: " + dstart);
                        Log.i(TAG, "filter: dend: " + dend);

                        if("1".contentEquals(source) || "0".contentEquals(source) ) {
                            return null;
                        }

                        return "?";
                    }
                }
        });

        final CheckBox checkBox = findViewById(R.id.checkBox);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    checkBox.setText("Вкл");
                } else {
                    checkBox.setText("Выкл");
                }
            }
        });

        SeekBar seekBar = findViewById(R.id.seekBar);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                Log.i(TAG, "onProgressChanged: progress: " + progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }
}
