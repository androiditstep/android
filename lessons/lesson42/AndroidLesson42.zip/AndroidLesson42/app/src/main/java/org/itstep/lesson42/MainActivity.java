package org.itstep.lesson42;

import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher {
    private TextInputLayout mTextInputLayoutLogin;
    private TextInputLayout mTextInputLayoutPassword;
    private EditText mEditTextLogin;
    private EditText mEditTextPassword;
    private Button mButtonSingIn;
    private TextView mTextViewWelcome;

    private static final String LOGIN = "admin";
    private static final String PASSWORD = "123456";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextInputLayoutLogin = findViewById(R.id.textInputLayoutLogin);
        mTextInputLayoutPassword = findViewById(R.id.textInputLayoutPassword);
        mTextViewWelcome = findViewById(R.id.textViewWelcome);
        mEditTextLogin = mTextInputLayoutLogin.getEditText();
        mEditTextPassword = mTextInputLayoutPassword.getEditText();
        mEditTextLogin.addTextChangedListener(this);
        mEditTextPassword.addTextChangedListener(this);
        mButtonSingIn = findViewById(R.id.buttonSingIn);
        mButtonSingIn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String login = mEditTextLogin != null ? mEditTextLogin.getText().toString() : null;
        String password = mEditTextPassword != null ? mEditTextPassword.getText().toString() : null;

        if(!LOGIN.equals(login)) {
            mTextInputLayoutLogin.setErrorEnabled(true);
            mTextInputLayoutLogin.setError("Incorrect Login");
        } else if(!PASSWORD.equals(password)) {
            mTextInputLayoutPassword.setErrorEnabled(true);
            mTextInputLayoutPassword.setError("Incorrect Password");
        } else {
            mTextInputLayoutPassword.setVisibility(View.GONE);
            mTextInputLayoutLogin.setVisibility(View.GONE);
            mButtonSingIn.setVisibility(View.GONE);
            mTextViewWelcome.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        mTextInputLayoutLogin.setError("");
        mTextInputLayoutPassword.setError("");
        mTextInputLayoutLogin.setErrorEnabled(false);
        mTextInputLayoutPassword.setErrorEnabled(false);
    }

    @Override
    public void afterTextChanged(Editable s) {

    }
}
