package org.itstep.activitydemo;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatImageView;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TableRow;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class ThirdActivity extends AppCompatActivity implements View.OnClickListener {

    public static final String TAG = "ThirdActivity";
    public static final String PICTURE = "picture";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        ViewGroup viewGroup = findViewById(R.id.gallery_layout);
        setForAllChildListener(viewGroup, AppCompatImageView.class, this);
    }

    <T> void setForAllChildListener(ViewGroup root, Class<T> clazz, View.OnClickListener listener) {
        for(int i=0; i<root.getChildCount(); i++) {
            if(root.getChildAt(i) instanceof ViewGroup) {
                setForAllChildListener((ViewGroup) root.getChildAt(i), clazz, listener);
            } else {
                View view = root.getChildAt(i);
                if(view.getClass() == clazz) {
                    view.setOnClickListener(listener);
                }
            }
        }
    }

    @Override
    public void onClick(View v) {
        if(!(v instanceof ImageView)) return;

        Drawable drawable=((ImageView)v).getDrawable();
        Bitmap bitmap= ((BitmapDrawable)drawable).getBitmap();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] b = baos.toByteArray();

        Intent intent = new Intent(this, PhotoViewActivity.class);
        intent.putExtra(PICTURE, b);
        startActivity(intent);
    }
}
