package org.itstep.listdemo;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayout linearLayout = findViewById(R.id.linear_layout);
        //programMakeList(linearLayout);
        LayoutInflater layoutInflater = getLayoutInflater();
        for(int i=0; i<100; i++){
            LinearLayout itemLinearLayout = (LinearLayout) layoutInflater
                    .inflate(R.layout.list_item, linearLayout, false);
            TextView textView = itemLinearLayout.findViewById(R.id.textView);

            textView.setText("Item: " + i);
//            LinearLayout.LayoutParams params =
//                    new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
//                            ViewGroup.LayoutParams.WRAP_CONTENT);
            linearLayout.addView(itemLinearLayout);
        }

    }

    private void programMakeList(LinearLayout linearLayout) {
        for(int i=0; i<100; i++){
            TextView textView = new TextView(this);
            textView.setText("Item: " + i);
            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                                                  ViewGroup.LayoutParams.WRAP_CONTENT);
            params.bottomMargin = 16;
            textView.setTextSize(16);
            textView.setTextColor(Color.RED);
            linearLayout.addView(textView, params);
        }
    }
}
