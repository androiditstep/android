package org.itstep.orientationdemo;

import android.content.pm.ActivityInfo;
import android.content.pm.ConfigurationInfo;
import android.content.res.Configuration;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Activity";
    DisplayMetrics dm = new DisplayMetrics();

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        metrix();

        Configuration config = getResources().getConfiguration();
        if(config.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Log.i(TAG, "onCreate: Landscape");
        }
        if(config.orientation == Configuration.ORIENTATION_PORTRAIT) {
            Log.i(TAG, "onCreate: Portrait");
        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }
        });
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    private void metrix() {
        Log.i(TAG, "onCreate: dpi " + dm.densityDpi);
        Log.i(TAG, "onCreate: width " + dm.widthPixels);
        Log.i(TAG, "onCreate: height " + dm.heightPixels);
        Log.i(TAG, "onCreate: scale " + dm.scaledDensity);
        Log.i(TAG, "onCreate: 100px = " + pxToDp(100) + "dp");
        Log.i(TAG, "onCreate: 100dp = " + dpToPx(100) + "px");

        ConstraintLayout.LayoutParams param = (ConstraintLayout.LayoutParams) button.getLayoutParams();
        param.width = (int) dpToPx(100);
        param.height = (int) dpToPx(50);
        button.setLayoutParams(param);
    }

    float pxToDp(float px) {
        return px/dm.scaledDensity;
    }

    float dpToPx(float dp) {
        return dp*dm.scaledDensity;
    }
}
