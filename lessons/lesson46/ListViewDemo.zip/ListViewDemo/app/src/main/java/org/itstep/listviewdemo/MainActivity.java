package org.itstep.listviewdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    List<CharSequence> items = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String[] countries = getResources().getStringArray(R.array.countries);
        Log.i(TAG, "onCreate: countries: " + Arrays.toString(countries));
        for(int i=0; i<countries.length; i++) {
            items.add(countries[i]);
        }

        ListView listView = findViewById(R.id.listView);
        ArrayAdapter<CharSequence> adapter = null; // ArrayAdapter.createFromResource(this, R.array.countries,
                                                  //             R.layout.item);

        adapter = new ArrayAdapter<>(this, R.layout.item, items);
        listView.setAdapter(adapter);

        final EditText editText = findViewById(R.id.editText);

        Button buttonAdd = findViewById(R.id.button_add);

        final ArrayAdapter<CharSequence> finalAdapter = adapter;
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String country = editText.getText().toString();
                items.add(country);
                finalAdapter.notifyDataSetChanged();
                editText.setText("");
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this, items.get(position), Toast.LENGTH_SHORT).show();
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                items.remove(position);
                finalAdapter.notifyDataSetChanged();
                return true;
            }
        });
    }
}
