package org.itstep.autocompletedemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ListView;
import android.widget.MultiAutoCompleteTextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<String> cities = new ArrayList<>();
    List<User> users = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initCities();
        initUsers();
        autocompleteDemo();

        ListView listView = findViewById(R.id.userListView);
        UserAdapter userAdapter = new UserAdapter(this, users);
        listView.setAdapter(userAdapter);
    }

    private void autocompleteDemo() {
        ArrayAdapter<String> citiesAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, cities);

        AutoCompleteTextView autoCompleteTextView = findViewById(R.id.autoCompleteTextView);

        autoCompleteTextView.setAdapter(citiesAdapter);

        MultiAutoCompleteTextView multiAutoCompleteTextView =
                findViewById(R.id.multiAutoCompleteTextView);
        multiAutoCompleteTextView.setAdapter(citiesAdapter);
        multiAutoCompleteTextView.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
    }

    private void initUsers() {
        users.add(new User("Barak", "+1234343233", R.drawable.barak));
        users.add(new User("John", "+8383838383", R.drawable.john));
    }

    private void initCities() {
        cities.add("Киев");
        cities.add("Днепр");
        cities.add("Харьков");
        cities.add("Каменское");
        cities.add("Кременчук");
        cities.add("Полтава");
    }
}
