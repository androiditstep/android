package org.itstep.autocompletedemo;

public class User {
    private static int count;
    private int id;
    private String name;
    private String phone;
    private int imageResource;

    public User(String name, String phone, int imageResource) {
        this.id = ++count;
        this.name = name;
        this.phone = phone;
        this.imageResource = imageResource;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getImageResource() {
        return imageResource;
    }

    public void setImageResource(int imageResource) {
        this.imageResource = imageResource;
    }
}
