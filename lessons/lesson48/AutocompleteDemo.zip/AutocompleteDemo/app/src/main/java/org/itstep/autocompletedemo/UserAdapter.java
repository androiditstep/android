package org.itstep.autocompletedemo;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

class UserAdapter extends BaseAdapter {
    private static final String TAG = "UserAdapter";
    Context context;
    List<User> list;
    public UserAdapter(Context context, List<User> users) {
        this.context = context;
        this.list = users;
    }

    @Override
    public int getCount() {
        Log.i(TAG, "getCount: " + list.size());
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        Log.i(TAG, "getItem: by position " + position);
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Log.i(TAG, "getView: position: " + position + " convertView: " + convertView);
        View view = LayoutInflater.from(context).inflate(R.layout.user_item, parent, false);

        ImageView imageViewPhoto = view.findViewById(R.id.imageViewPhoto);
        TextView textViewName = view.findViewById(R.id.textViewName);
        TextView textViewPhone = view.findViewById(R.id.textViewPhone);

        User user = (User) getItem(position);
        imageViewPhoto.setImageResource(user.getImageResource());
        textViewName.setText(user.getName());
        textViewPhone.setText(user.getPhone());

        return view;
    }
}
