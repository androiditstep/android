package org.itstep.menuandactivity;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final int NEW_ITEM_REQUEST_CODE = 101;
    private static final String TAG = "MainActivity";
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textViewResult);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode) {
            case NEW_ITEM_REQUEST_CODE:
                if(resultCode == RESULT_OK) {
                    String name = MyApplication.getProductStorage().getLastName();
                            //data.getStringExtra(NewItemActivity.EXTRA_NAME);
                    textView.setText(String.format("Hello: %s", name));
                } else {
                    Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                break;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.itemSearch:
                break;
            case R.id.itemAdd:
                Intent intent = new Intent(this, NewItemActivity.class);
                startActivityForResult(intent, NEW_ITEM_REQUEST_CODE);
                break;
            case R.id.itemRemove:
                break;
            case R.id.itemSort:
                break;
        }
        Toast.makeText(this, item.getTitle(), Toast.LENGTH_SHORT).show();
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
}
