package org.itstep.menuandactivity;

import android.app.Application;

public class MyApplication extends Application {
    private static ProductStorage productStorage;
    @Override
    public void onCreate() {
        super.onCreate();
        productStorage = ProductStorage.getInstance();
    }

    public static ProductStorage getProductStorage() {
        return productStorage;
    }
}
