package org.itstep.menuandactivity;

import android.app.Application;

import java.util.ArrayList;
import java.util.List;

public class ProductStorage {

    private static final ProductStorage ourInstance = new ProductStorage();

    private List<String> names = new ArrayList<>();

    public static ProductStorage getInstance() {
        return ourInstance;
    }

    private ProductStorage() {
    }

    public void addName(String name) {
        names.add(name);
    }

    public String getLastName() {
        return names.get(size()-1);
    }

    public int size() {
        return names.size();
    }
}
