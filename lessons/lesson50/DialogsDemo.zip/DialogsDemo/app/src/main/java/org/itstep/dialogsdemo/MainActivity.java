package org.itstep.dialogsdemo;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

//        Point.Builder builder = new Point.Builder();
//        Point point = builder.setZ(10)
//                             .setY(20).build();

        final String[] countries = {"USA", "Canada", "France", "Ukraine"};
        DialogInterface.OnClickListener clickListListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int position) {
                Toast.makeText(MainActivity.this,
                        "Selected " + countries[position], Toast.LENGTH_LONG).show();
            }
        };

        View dialogLayout = LayoutInflater.from(this)
                .inflate(R.layout.dilog, null, false);
        final EditText dialogEditText = dialogLayout.findViewById(R.id.editText); // ???

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("It is title")
                //.setMessage("It is simple message")
                //.setItems(countries, clickListListener)
                //.setSingleChoiceItems(countries, 0, clickListListener)
//                .setMultiChoiceItems(countries, null, new DialogInterface.OnMultiChoiceClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int position, boolean isChecked) {
//                        String msg = isChecked ? "Checked" : "Unchecked";
//                        Toast.makeText(MainActivity.this,
//                                msg + " " + countries[position], Toast.LENGTH_LONG).show();
//                    }
//                })
                .setView(dialogLayout)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(DialogInterface.BUTTON_POSITIVE == which) {
                            if(dialogEditText != null) {
                                Toast.makeText(MainActivity.this,
                                        "Name = " + dialogEditText.getText().toString(),
                                        Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(MainActivity.this,
                                        "Error",
                                        Toast.LENGTH_SHORT).show();
                            }
                            dialog.dismiss();
                        }
                    }
                })
                .setNegativeButton("Cancel", null);
        final AlertDialog dialog = builder.create();

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
                dialog.show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
