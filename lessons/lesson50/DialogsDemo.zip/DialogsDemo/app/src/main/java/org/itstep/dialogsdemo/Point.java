package org.itstep.dialogsdemo;

public class Point {
    private int x, y, z;

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getZ() {
        return z;
    }

    public static class Builder {
        private Point point = new Point();

        public Builder setX(int x) {
            point.x = x;
            return this;
        }

        public Builder setY(int y) {
            point.y = y;
            return this;
        }

        public Builder setZ(int z) {
            point.z = z;
            return this;
        }

        public Point build() {
            return point;
        }
    }
}
