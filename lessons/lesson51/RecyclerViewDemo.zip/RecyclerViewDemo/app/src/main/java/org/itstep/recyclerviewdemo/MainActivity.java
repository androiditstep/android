package org.itstep.recyclerviewdemo;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    static int count;
    private static final String TAG = "MainActivity";
    private RecyclerView mRecyclerView;
    private List<Person> mPeople;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mRecyclerView = findViewById(R.id.recyclerView);
        // set LayoutManager
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
//        mRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        initPeople();

        // set Adapter
        mRecyclerView.setAdapter(new PeopleAdapter(mPeople));

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mPeople.add(new Person(R.mipmap.ic_launcher_round, "Рома"));
                mRecyclerView.getAdapter().notifyItemInserted(mPeople.size()-1);
            }
        });
    }

    private void initPeople() {
        mPeople = new ArrayList<>();
        //for(int i=0; i<100; i++) {
            mPeople.add(new Person(R.mipmap.ic_launcher_round, "Вася"));
            mPeople.add(new Person(R.mipmap.ic_launcher_round, "Маша"));
//            mPeople.add(new Person(R.mipmap.ic_launcher_round, "Петя"));
//            mPeople.add(new Person(R.mipmap.ic_launcher_round, "Даша"));
//            mPeople.add(new Person(R.mipmap.ic_launcher_round, "Рома"));
        //}
    }

    class PeopleAdapter extends RecyclerView.Adapter<PeopleAdapter.ViewHolder> {

        List<Person> people;

        public PeopleAdapter(List<Person> people) {
            this.people = people;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(MainActivity.this)
                                      .inflate(R.layout.person_item, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Log.i(TAG, "onBindViewHolder: recycle holder #" + holder.id);
            Person item = people.get(position);
            holder.textViewId.setText(String.valueOf(item.getId()));
            holder.textViewName.setText(item.getName());
            holder.imageViewPhoto.setImageResource(item.getPhotoId());
        }

        @Override
        public int getItemCount() {
            return people.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            int id;
            ImageView imageViewPhoto;
            TextView textViewId;
            TextView textViewName;

            public ViewHolder(View itemView) {
                super(itemView);
                id = ++count;
                Log.i(TAG, "ViewHolder: Created #" + id);
                imageViewPhoto = itemView.findViewById(R.id.imageViewPhoto);
                textViewId = itemView.findViewById(R.id.textViewId);
                textViewName = itemView.findViewById(R.id.textViewName);
            }
        }
    }

}
