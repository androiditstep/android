package org.itstep.recyclerviewdemo;

public class Person {
    static int count;

    int id;
    int photoId;
    String name;

    public Person(int photoId, String name) {
        this.id = ++count;
        this.photoId = photoId;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPhotoId() {
        return photoId;
    }

    public void setPhotoId(int photoId) {
        this.photoId = photoId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Person{" +
                "id=" + id +
                ", photoId=" + photoId +
                ", name='" + name + '\'' +
                '}';
    }
}
