package org.itstep.notificationsdemo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;

import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final String CHANNEL_ID = "Demo channel";
    public static final int NOTIFICATION_ID = 1;
    NotificationManager notificationManager;

    int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    }

    public void sendNotification(View view) {

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
//                    "Important channel", NotificationManager.IMPORTANCE_DEFAULT);
//            notificationManager.createNotificationChannel(channel);
//        }
//
//        Intent intent = new Intent(this, MainActivity.class);
//        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent,
//                PendingIntent.FLAG_UPDATE_CURRENT);
//
//        RemoteViews remoteViews = new RemoteViews(getPackageName(), R.layout.custom_notification);
//        Intent mapIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:48.4728735,35.0259948?z=17"));
//        remoteViews.setOnClickPendingIntent(R.id.imageView3,
//                PendingIntent.getActivity(this, 0, mapIntent, PendingIntent.FLAG_UPDATE_CURRENT));
//        String bigText = getResources().getString(R.string.text);
//
//        NotificationCompat.Builder builder =
//                new NotificationCompat.Builder(this, CHANNEL_ID)
//                        .setSmallIcon(R.mipmap.ic_launcher_round)
//                        .setContentTitle("Simple notification")
//                        .setContentText("Content this notification")
//                        .setOngoing(true)
//                        .setAutoCancel(true)
//                        .setStyle(new NotificationCompat.BigTextStyle()
//                                                        .bigText(bigText)
//                                                        .setBigContentTitle("Content title")
//                                                        .setSummaryText("Summary")
//                        )
////                        .setContentIntent(pendingIntent)
////                        .addAction(R.mipmap.ic_launcher, "Button", pendingIntent)
////                        .setContent(remoteViews)
//                        .setNumber(++count)
//                        //.setTimeoutAfter(3000)
//                        .setShowWhen(true)
//                        .setWhen(System.currentTimeMillis() + 5000)
//                        .setChannelId(CHANNEL_ID);
//
//        final Notification notification = builder.build();
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    Thread.sleep(5000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//                notificationManager.notify(NOTIFICATION_ID, notification);
//            }
//        }).start();
        NewMessageNotification.notify(this, "test", 1);
    }

    public void clearNotification(View view) {
        notificationManager.cancel(NOTIFICATION_ID);
    }
}
