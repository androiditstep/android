package org.itstep.fragmentdemo;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.CharacterPickerDialog;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnLongClickListener, TimePickerDialog.OnTimeSetListener, DatePickerDialog.OnDateSetListener {

    private static final String TAG = "MainActivity";
    TextView textView;
    Date date;
    Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        textView.setOnLongClickListener(this);
    }

    @Override
    public boolean onLongClick(View v) {
        PopupMenu popupMenu = new PopupMenu(this, v);
        popupMenu.setGravity(Gravity.RIGHT);
        MenuInflater inflater = popupMenu.getMenuInflater();
        Menu menu = popupMenu.getMenu();
        inflater.inflate(R.menu.context_color, menu);
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                textView.setTextColor(Color.WHITE);
                switch (item.getItemId()) {
                    case R.id.item_blue:
                        textView.setBackgroundColor(Color.BLUE);
                        break;
                    case R.id.item_green:
                        textView.setBackgroundColor(Color.GREEN);
                        break;
                    case R.id.item_red:
                        textView.setBackgroundColor(Color.RED);
                        break;
                }
                return true;
            }
        });
        popupMenu.show();
        return true;
    }

    public void showDialog(View view) {
        calendar = Calendar.getInstance();
        switch (view.getId()) {
            case R.id.button_time:
                calendar.add(Calendar.MINUTE, -50);
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int min = calendar.get(Calendar.MINUTE);
                TimePickerDialog timePickerDialog =
                        new TimePickerDialog(this, this,
                                hour, min, true);
                timePickerDialog.show();
                break;
            case R.id.button_date:
                Log.i(TAG, "showDialog: ");
                DatePickerDialog datePickerDialog = new DatePickerDialog(this, this,
                        calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DATE));
                datePickerDialog.show();
                break;
        }
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        textView.setText(String.format("%d:%d", hourOfDay, minute));
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        textView.setText(String.format("%d/%d/%d", dayOfMonth, month+1, year));
    }
}
