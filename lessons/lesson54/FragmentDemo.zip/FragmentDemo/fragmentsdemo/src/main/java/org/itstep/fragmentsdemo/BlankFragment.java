package org.itstep.fragmentsdemo;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class BlankFragment extends Fragment {

    private static final String TEXT_KEY = "text_key";

    public static Fragment getInstance(String text) {
        BlankFragment blankFragment = new BlankFragment();
        Bundle bundle = new Bundle();
        bundle.putString(TEXT_KEY, text);
        blankFragment.setArguments(bundle);
        return blankFragment;
    }

    public BlankFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_blank, container, false);
        TextView textView = view.findViewById(R.id.textViewInFragment);

        Bundle bundle = getArguments();
        String text = "";
        if(bundle != null) {
            text = bundle.getString(TEXT_KEY);
        }
        textView.setText(text);
        return view;
    }

}
