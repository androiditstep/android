package org.itstep.fragmentsdemo;

import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    RecyclerView dishesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dishesList = findViewById(R.id.dishesList);
        dishesList.setLayoutManager(new LinearLayoutManager(this));
        dishesList.setAdapter(new DishAdapter(DishSource.dishes));
    }

    private class DishAdapter extends RecyclerView.Adapter<DishAdapter.ViewHolder> {
        List<Dish> dishes;

        public DishAdapter(List<Dish> dishes) {
            this.dishes = dishes;
        }

        @NonNull
        @Override
        public DishAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ViewHolder(LayoutInflater.from(getApplicationContext())
                    .inflate(R.layout.list_item, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull DishAdapter.ViewHolder holder, int position) {
            final Dish dish = dishes.get(position);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.i(TAG, "onClick: " + dish);
                    // FIXME: Отобразить активность с детальным описанием блюда
                }
            });
            holder.textView.setText(dish.getName());
            try {
                InputStream in = getApplicationContext().getAssets().open(dish.getImage());
                Drawable drawable = Drawable.createFromStream(in, dish.getImage());
                holder.imageView.setImageDrawable(drawable);
            } catch (IOException e) {
                Log.e(TAG, "onBindViewHolder: " + dish.getImage(), e);
            }
        }

        @Override
        public int getItemCount() {
            return dishes.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView textView;
            ImageView imageView;
            public ViewHolder(View itemView) {
                super(itemView);
                textView = itemView.findViewById(R.id.itemNameText);
                imageView = itemView.findViewById(R.id.imageView);
            }
        }
    }
}
