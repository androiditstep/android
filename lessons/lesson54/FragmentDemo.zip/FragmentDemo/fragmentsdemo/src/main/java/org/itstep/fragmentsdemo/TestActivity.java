package org.itstep.fragmentsdemo;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class TestActivity extends AppCompatActivity {

    private static final String TAG_FRAGMENT = "blank_fragment_tag";
    BlankFragment fragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        fragment = new BlankFragment();
    }

    public void fragmentAction(View view) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        String text;
        Fragment f = fragmentManager.findFragmentByTag(TAG_FRAGMENT);
        switch (view.getId()) {
            case R.id.btn_add_fragment:
//                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//                fragmentTransaction.add(R.id.host_fagment, fragment);
//                fragmentTransaction.commit();
                text = "first fragment";
                if(f == null) {
                    fragmentManager.beginTransaction()
                            .add(R.id.host_fragment, BlankFragment.getInstance(text), TAG_FRAGMENT)
                            .commit();
                }
                break;
            case R.id.btn_remove_fragment:
                if(f != null) {
                    fragmentManager.beginTransaction()
                            .remove(f)
                            .commit();
                }
                break;
            case R.id.btn_replace_fragment:
                text = "second fragment";
                fragmentManager.beginTransaction()
                        .replace(R.id.host_fragment, BlankFragment.getInstance(text), TAG_FRAGMENT)
                        .commit();
                break;
        }
    }
}
