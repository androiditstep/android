package org.itstep.simplefragment;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_details);

        Intent intent = getIntent();
        if(intent != null) {
            String item = intent.getStringExtra("EXTRA_ITEM");
            TextView textView = findViewById(R.id.textView);
            textView.setText(item);
        }
    }
}
