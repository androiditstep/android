package org.itstep.simplefragment;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.itstep.simplefragment.fragment.DetailsFragment;
import org.itstep.simplefragment.fragment.ListFragment;

public class MainActivity extends AppCompatActivity implements ListFragment.ListListener,
        DetailsFragment.OnFragmentInteractionListener {

    private static final String TAG = "MainActivity";
    boolean isOnePanel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FrameLayout frameLayout = findViewById(R.id.details_fragment);
        isOnePanel = frameLayout == null;

        Log.i(TAG, "onCreate: isOnePanel " + isOnePanel);


    }

    @Override
    public void onItemClicked(String item) {
        Toast.makeText(this, "Item clicked: " + item, Toast.LENGTH_SHORT).show();
        if (isOnePanel) {
            // start activity
            Intent intent = new Intent(this, DetailsActivity.class);
            intent.putExtra("EXTRA_ITEM", item);
            startActivity(intent);
        } else {
            // replace fragment
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.details_fragment, DetailsFragment.newInstance(item))
                    .commit();
        }
    }

    @Override
    public void onFragmentInteraction(Uri uri) {
        
    }
}
