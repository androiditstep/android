package org.itstep.fragmentsdemo.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.UUID;

public class Dish {

    private String id;
    private String name;
    private String description;
    private String category;
    private int sortPosition;
    private double price;
    private String image;

    public Dish() {
    }

    public Dish(String itemId, String itemName, String category, String description, int sortPosition, double price, String image) {

        if (itemId == null) {
            itemId = UUID.randomUUID().toString();
        }

        this.id = itemId;
        this.name = itemName;
        this.description = description;
        this.category = category;
        this.sortPosition = sortPosition;
        this.price = price;
        this.image = image;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getSortPosition() {
        return sortPosition;
    }

    public void setSortPosition(int sortPosition) {
        this.sortPosition = sortPosition;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return name;
    }
}
