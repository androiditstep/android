package org.itstep.simplefragment.fragment;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.itstep.simplefragment.R;

import java.util.ArrayList;
import java.util.List;


public class ListFragment extends Fragment {

    public interface ListListener {
        void onItemClicked(String item);
    }

    ListListener listListener;
    ListView listView;

    public ListFragment() {
        // Required empty public constructor
        for(int i=0; i<10; i++) {
            data.add("One");
            data.add("Two");
            data.add("Three");
            data.add("Four");
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof ListListener) {
            listListener = (ListListener) context;
        }
    }

    List<String> data = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_list, container, false);
        listView = view.findViewById(R.id.simple_list_view);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getContext(),
                android.R.layout.simple_list_item_1, data);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(listListener != null) {
                    listListener.onItemClicked(data.get(position));
                }
            }
        });
        return view;
    }

}
