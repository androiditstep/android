package org.itstep.imagesdemo;

import android.content.res.AssetManager;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    Drawable img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int resId = R.drawable.black_star;
        //Drawable drawable = getResources().getDrawable(resId);

        AssetManager assets = getAssets();
        try {
            // InputStream - поток байт изображения
            InputStream in = assets.open("dice.png");
            img = Drawable.createFromStream(in, "dice");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void changeImage(View view) {
        if(view instanceof ImageView) {
            ImageView imageView = (ImageView) view;
            imageView.setImageDrawable(img);
        }
    }
}
