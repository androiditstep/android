package org.itstep.imagesdemo;

import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("d/M/yyyy H:m:s");
        for(int i=0; i<30; i++) {
            System.out.println(simpleDateFormat.format(calendar.getTime()));
            calendar.add(Calendar.WEEK_OF_MONTH, 1);
        }
    }
}