package org.itstep.animationdemo;

import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private ImageView imageView;
    AnimationDrawable animationDrawable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = findViewById(R.id.imageView);
        AssetManager assetManager = getAssets();

        TextView textView = findViewById(R.id.textView);
        textView.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/kobzar.ttf"));

        imageView.setBackgroundResource(R.drawable.monkey_anim);
        animationDrawable = (AnimationDrawable) imageView.getBackground();
    }

    public void startAnimation(View view) {
        //manualAnimation();
        if(!animationDrawable.isRunning()) {
            animationDrawable.start();
        } else {
            animationDrawable.stop();
        }
    }

    private void manualAnimation() {
        final AssetManager assetManager = getAssets();
        try {
            final String[] monkeys = assetManager.list("monkey");
            Log.i(TAG, "onCreate: filename: " + Arrays.toString(monkeys));
            new Thread(new Runnable() {
                @Override
                public void run() {
                    for (final String imageName : monkeys) {
                        InputStream monkeyStream = null;
                        try {
                            monkeyStream = assetManager.open("monkey/" + imageName);
                            final InputStream finalMonkeyStream = monkeyStream;
                            imageView.post(new Runnable() {
                                @Override
                                public void run() {
                                    imageView.setImageDrawable(Drawable.createFromStream(finalMonkeyStream, "monkey.jpg"));
                                }
                            });
                            Log.i(TAG, "onCreate: showImage " + imageName);
                            Thread.sleep(100);
                        } catch (IOException | InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
