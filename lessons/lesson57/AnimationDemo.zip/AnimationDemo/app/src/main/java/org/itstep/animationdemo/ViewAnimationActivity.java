package org.itstep.animationdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class ViewAnimationActivity extends AppCompatActivity {

    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_animation);
        imageView = findViewById(R.id.imageView2);
    }

    public void scaleAnimDemo(View view) {
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.scale_anim);
        imageView.startAnimation(animation);
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                imageView.setScaleX(1.5f);
                imageView.setScaleY(1.5f);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }
}
