package org.itstep.animationdemo2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
    Animation animSimple;
    Animation animParent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        animSimple = AnimationUtils.loadAnimation(this, R.anim.anim_simple);
        animParent = AnimationUtils.loadAnimation(this, R.anim.anim_parent);
//        animParent = AnimationUtils.loadAnimation(this, android.R.anim.fade_in);

    }

    public void translateSimple(View view) {
        imageView.startAnimation(animSimple);
    }

    public void translateParent(View view) {
        imageView.startAnimation(animParent);
    }

    public void newActivityStartNow(View view) {
        Intent intent = new Intent(this, SecondActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
    }
}
