package org.itstep.animationdemo2;

import android.animation.Animator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;

public class ViewPropAnimActivity extends AppCompatActivity {

    private static final String TAG = "ViewPropAnimActivity";
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_prop_anim);
        imageView = findViewById(R.id.imageView2);
    }

    public void startImageViewAnimation(View view) {
        imageView.animate()
                .setDuration(2000)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .rotationXBy(180)
                .setListener(new Animator.AnimatorListener() {
                    @Override
                    public void onAnimationStart(Animator animation) {
                        Log.i(TAG, "onAnimationStart: ");
                    }

                    @Override
                    public void onAnimationEnd(Animator animation) {
                    }

                    @Override
                    public void onAnimationCancel(Animator animation) {

                    }

                    @Override
                    public void onAnimationRepeat(Animator animation) {

                    }
                })
                .start();
    }
}
