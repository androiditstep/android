package org.itstep.valueanimatordemo;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.BounceInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private ImageView imageViewHomer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageViewHomer = findViewById(R.id.imageViewHomer);

        getSupportFragmentManager()
                .beginTransaction()
                //.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                .setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out)
                .commit();
    }

    public void runHomer(View view) {
        ObjectAnimator animatorDownHomer = ObjectAnimator.ofFloat(imageViewHomer, View.Y,
                imageViewHomer.getY(), imageViewHomer.getY() + 600);
        animatorDownHomer.setInterpolator(new BounceInterpolator());
        animatorDownHomer.setDuration(5000);

        ObjectAnimator alphaAnimatorHomer = ObjectAnimator.ofFloat(imageViewHomer, View.ALPHA,
                0, 1)
                .setDuration(3000);

        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playSequentially(alphaAnimatorHomer, animatorDownHomer);//.playTogether(animatorDownHomer, alphaAnimatorHomer);
        animatorSet.start();

        //viewAnimatorDemo();
    }

    private void viewAnimatorDemo() {
        final ValueAnimator anim = ValueAnimator.ofFloat(imageViewHomer.getY(),
                imageViewHomer.getY() + 600)
                .setDuration(5000);
//        anim.setRepeatCount(3);
        anim.setInterpolator(new BounceInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                //Log.i(TAG, "Value: " + animation.getAnimatedValue());
                Log.i(TAG, "onAnimationUpdate: time = " + animation.getCurrentPlayTime());
                imageViewHomer.setY((Float) animation.getAnimatedValue());
            }
        });

        anim.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
                Log.i(TAG, "onAnimationStart: ");
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                Log.i(TAG, "onAnimationEnd: ");
            }

            @Override
            public void onAnimationCancel(Animator animation) {
                Log.i(TAG, "onAnimationCancel: ");
            }

            @Override
            public void onAnimationRepeat(Animator animation) {
                Log.i(TAG, "onAnimationRepeat: ");
            }
        });

        anim.start();
    }


}
