package org.itstep.transitionanimation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.ChangeBounds;
import android.transition.Scene;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.view.View;
import android.view.ViewGroup;

public class MainActivity extends AppCompatActivity {

    ViewGroup rootLayout;
    Scene scene1;
    Scene scene2;

    boolean toSecondScene;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rootLayout = findViewById(R.id.rootLayout);
        scene1 = Scene.getSceneForLayout(rootLayout, R.layout.scene1, this);
        scene2 = Scene.getSceneForLayout(rootLayout, R.layout.scene2, this);
    }

    public void startAnim(View view) {
        Transition transition = new ChangeBounds();
        transition.setDuration(5000);
        if(!toSecondScene) {
            TransitionManager.go(scene2, transition);
        } else {
            TransitionManager.go(scene1, transition);
        }
        toSecondScene = !toSecondScene;
    }
}
