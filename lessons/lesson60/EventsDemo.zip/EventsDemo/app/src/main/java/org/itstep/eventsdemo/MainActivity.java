package org.itstep.eventsdemo;

import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    TextView textView;
    View square;
    FrameLayout container;
    float[] x = {0f, 0f};
    float[] y = {0f, 0f};
    float[] size = {0f, 0f};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        square = findViewById(R.id.square);
        container = findViewById(R.id.container);

        container.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                size[0] = container.getWidth();
                size[1] = container.getHeight();
            }
        });
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        Log.i(TAG, "onTouchEvent: " + event);

        int action = event.getAction();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                Log.i(TAG, "onTouchEvent: Start action");
                x[0] = event.getX();
                y[0] = event.getY();
                break;
            case MotionEvent.ACTION_UP:
                Log.i(TAG, "onTouchEvent: End action");
                x[1] = event.getX();
                y[1] = event.getY();
                moveSquare();
                break;
        }


        return super.onTouchEvent(event);
    }

    private void moveSquare() {
        float dx = x[0] - x[1];
        float dy = y[0] - y[1];

        int sw = square.getWidth();
        int sh = square.getHeight();


        if (Math.abs(dy) > Math.abs(dx)) { // Vertical motion
            if (dy > 0) { // Up
                textView.setText("Move Up");
                square.animate()
                        .translationYBy(sh - size[1])
                        .setDuration(1000);
            } else {    // Down
                textView.setText("Move Up");
                square.animate()
                        .translationYBy(size[1] - sh)
                        .setDuration(1000);

            }
        } else { // Horizontal motion
            if (dx > 0) { // Left
                textView.setText("Move Left");
                square.animate()
                        .translationXBy(sw - size[0])
                        .setDuration(1000);
            } else {     // Right
                textView.setText("Move Right");
                square.animate()
                        .translationXBy(size[0] - sw)
                        .setDuration(1000);
            }
        }
    }
}
