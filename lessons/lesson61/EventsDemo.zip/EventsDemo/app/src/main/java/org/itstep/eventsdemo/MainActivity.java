package org.itstep.eventsdemo;

import android.support.constraint.ConstraintLayout;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v4.view.ScaleGestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.BounceInterpolator;
import android.widget.FrameLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    TextView textView;
    View square;
    FrameLayout container;
    float[] x = {0f, 0f};
    float[] y = {0f, 0f};
    float[] size = {0f, 0f};
    float initTextSize;

    VelocityTracker velocityTracker;

    private GestureDetectorCompat mGestureDetector;
    private ScaleGestureDetector mScaleGestureDetector;

    private ScaleGestureDetector.OnScaleGestureListener scaleGestureListener =
            new ScaleGestureDetector.SimpleOnScaleGestureListener(){
                @Override
                public boolean onScaleBegin(ScaleGestureDetector detector) {
                    Log.i(TAG, "onScaleBegin: ");
                    return super.onScaleBegin(detector);
                }

                @Override
                public boolean onScale(ScaleGestureDetector detector) {
                    Log.i(TAG, "onScale: ");
//                    textView.setText("ScaleFactor: " + detector.getScaleFactor());
                    textView.setTextSize(initTextSize * detector.getScaleFactor());
                    return super.onScale(detector);
                }

                @Override
                public void onScaleEnd(ScaleGestureDetector detector) {
                    Log.i(TAG, "onScaleEnd: ");
                    super.onScaleEnd(detector);
                }
            };


    private GestureDetector.SimpleOnGestureListener gestureListener =
            new GestureDetector.SimpleOnGestureListener(){

                @Override
                public boolean onScroll(MotionEvent e1, MotionEvent e2,
                                        float distanceX, float distanceY) {
                    Log.i(TAG, "onScroll: dx: " + distanceX + " dy: " + distanceY);
                    moveSquare(distanceX, distanceY);
                    return true;
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        initTextSize = textView.getTextSize();
        square = findViewById(R.id.square);
        container = findViewById(R.id.container);

        container.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                size[0] = container.getWidth();
                size[1] = container.getHeight();
            }
        });

        mGestureDetector = new GestureDetectorCompat(this, gestureListener);
        mGestureDetector.setOnDoubleTapListener(gestureListener);
        mGestureDetector.setIsLongpressEnabled(true);

        mScaleGestureDetector = new ScaleGestureDetector(this, scaleGestureListener);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
//        Log.i(TAG, "onTouchEvent: " + event);
        if(mGestureDetector.onTouchEvent(event)){

        }else{
            mScaleGestureDetector.onTouchEvent(event);
        }

        int action = event.getAction();
        if(action == MotionEvent.ACTION_DOWN) {
            velocityTracker = VelocityTracker.obtain();
        } else {
            velocityTracker.addMovement(event);
            Log.i(TAG, "onTouchEvent: velocity x: " + velocityTracker.getXVelocity());
            Log.i(TAG, "onTouchEvent: velocity y: " + velocityTracker.getYVelocity());
        }
//        int action = event.getAction();
//        switch (action) {
//            case MotionEvent.ACTION_DOWN:
//                Log.i(TAG, "onTouchEvent: Start action");
//                x[0] = event.getX();
//                y[0] = event.getY();
//                break;
//            case MotionEvent.ACTION_UP:
//                Log.i(TAG, "onTouchEvent: End action");
//                x[1] = event.getX();
//                y[1] = event.getY();
//                moveSquare(x[0] - x[1], y[0] - y[1]);
//                break;
//        }
        return super.onTouchEvent(event);
    }

    private void moveSquare(float dx, float dy) {

        int sw = square.getWidth();
        int sh = square.getHeight();


        if (Math.abs(dy) > Math.abs(dx)) { // Vertical motion
            if (dy > 0) { // Up
                textView.setText(R.string.move_up);
                square.animate()
                        .translationYBy(sh - size[1])
                        .setInterpolator(new BounceInterpolator())
                        .setDuration(1000);
            } else {    // Down
                textView.setText(R.string.move_down);
                square.animate()
                        .translationYBy(size[1] - sh)
                        .setInterpolator(new BounceInterpolator())
                        .setDuration(1000);

            }
        } else { // Horizontal motion
            if (dx > 0) { // Left
                textView.setText(R.string.move_left);
                square.animate()
                        .translationXBy(sw - size[0])
                        .setInterpolator(new BounceInterpolator())
                        .setDuration(1000);
            } else {     // Right
                textView.setText(R.string.move_right);
                square.animate()
                        .translationXBy(size[0] - sw)
                        .setInterpolator(new BounceInterpolator())
                        .setDuration(1000);
            }
        }
    }
}
