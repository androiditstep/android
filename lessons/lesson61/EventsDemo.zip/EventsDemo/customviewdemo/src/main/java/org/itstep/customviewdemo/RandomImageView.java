package org.itstep.customviewdemo;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.AppCompatImageView;
import android.util.AttributeSet;

import java.io.IOException;
import java.io.InputStream;
import java.util.Random;

public class RandomImageView extends AppCompatImageView {
    Random random = new Random();

    public void nextRandom() {
        AssetManager assets = getContext().getAssets();
        try {
            String[] list = assets.list("");
            String fileName = list[random.nextInt(list.length)];
            InputStream open = assets.open(fileName);
            setBackground(Drawable.createFromStream(open, fileName));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public RandomImageView(Context context) {
        super(context);
    }

    public RandomImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public RandomImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
