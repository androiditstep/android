package org.itstep.impliciteintents;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class BrowserActivity extends AppCompatActivity {

    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);

        textView = findViewById(R.id.textView);

        Intent intent = getIntent();
        textView.setText("action: " + intent.getAction()
                + " uri: " + intent.getData());
    }
}
