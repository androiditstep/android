package org.itstep.impliciteintents;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

//    private TextView textView;
    private int counter;
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        textView = findViewById(R.id.textView);

        if(savedInstanceState != null) {
            counter = savedInstanceState.getInt("counter");
        }

//        textView.setText(String.valueOf(counter));
        editText = findViewById(R.id.editText);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("counter", counter);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
//        textView.setText(String.valueOf(++counter));
        return super.onTouchEvent(event);
    }

    public void goActivity(View view) {
        Uri uri = Uri.parse(editText.getText().toString());
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        if(intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this, "No activity found", Toast.LENGTH_LONG).show();
        }
    }
}
