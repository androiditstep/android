package org.itstep.broadcastdemo;

import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private EditText editText;

    CustomReceiver customReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.editText);

        customReceiver = new CustomReceiver();
        IntentFilter intentFilter = new IntentFilter("org.itstep.broadcastdemo.VIEW");
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(customReceiver, intentFilter);
    }

    public void send(View view) {
        Intent intent = new Intent("org.itstep.broadcastdemo.VIEW");
        intent.putExtra("text", editText.getText().toString());
        LocalBroadcastManager.getInstance(this)
                .sendBroadcast(intent);
//        sendBroadcast(intent);
        Log.i(TAG, "send: ");
    }

    @Override
    protected void onStop() {
        LocalBroadcastManager.getInstance(this)
                .unregisterReceiver(customReceiver);
        super.onStop();
    }
}
