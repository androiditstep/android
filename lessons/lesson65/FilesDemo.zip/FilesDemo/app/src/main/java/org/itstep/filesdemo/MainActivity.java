package org.itstep.filesdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    public static final String FILE_NAME = "data";
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
    }

    public void saveToFile(View view) {
        String text = editText.getText().toString();
        save(text);
    }

    private void save(String text) {
        OutputStream out = null;
        PrintStream printStream = null;
        try {
            out = openFileOutput(FILE_NAME, MODE_APPEND);
            printStream = new PrintStream(out);
            //out.write(text.getBytes());
            printStream.print(text);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void readFromFile(View view) {
        editText.setText(read());
    }

    private String read() {
        InputStream in = null;
        StringBuilder textBuilder = new StringBuilder();
        Scanner scanner;
        try {
            in = openFileInput(FILE_NAME);
            scanner = new Scanner(in);
            String str = scanner.nextLine();
            textBuilder.append(str);
//            byte[] buff = new byte[255];
//            int count = -1;
//            while ((count = in.read(buff, 0, buff.length)) > 0){
//                String str = new String(buff, 0, count);
//                textBuilder.append(str);
//            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return textBuilder.toString();
    }
}
