package org.itstep.servicesdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public static final String ACTION_RECEIVE = "org.itstep.servicesdemo.ACTION_RECEIVE";
    public static final String EXTRA_VALUE = "extra_value";
    private static final String TAG = "MainActivity";
    ProgressBar progressBar;
    TextView textView;

    BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int value = intent.getIntExtra(EXTRA_VALUE, 0);
            updateUI(value);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(TAG, "onCreate: ");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bindViews();
    }

    @Override
    protected void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(receiver, new IntentFilter(ACTION_RECEIVE));
    }

    private void bindViews() {
        progressBar = findViewById(R.id.progressBar);
        textView = findViewById(R.id.textView);
    }

    private void updateUI(int value) {
        progressBar.setProgress(value);
        textView.setText(String.valueOf(value));
    }

    public void runService(View view) {
        startService(new Intent(this, StartedService.class));
    }

    public void killService(View view) {
        stopService(new Intent(this, StartedService.class));
    }

    @Override
    protected void onStop() {
        Log.i(TAG, "onStop: ");
        super.onStop();
        if(receiver != null) {
            LocalBroadcastManager.getInstance(this)
                    .unregisterReceiver(receiver);
        }
    }
}
