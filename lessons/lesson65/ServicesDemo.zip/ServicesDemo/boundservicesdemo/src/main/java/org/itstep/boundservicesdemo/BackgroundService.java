package org.itstep.boundservicesdemo;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

public class BackgroundService extends Service {
    public static final String TAG = "BackgroundService";
    public BackgroundService() {
        Log.i(TAG, "BackgroundService: ");
    }

    public class ServiceBinder extends Binder {
        public BackgroundService getService() {
            return BackgroundService.this;
        }
    }

    ServiceBinder binder = new ServiceBinder();

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "onCreate: ");
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.i(TAG, "onBind: ");
        return binder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.i(TAG, "onUnbind: ");
        return super.onUnbind(intent);        
    }

    @Override
    public void onDestroy() {        
        super.onDestroy();
        Log.i(TAG, "onDestroy: ");
    }

    public void method() {
        Log.i(TAG, "method: ");
    }
}
