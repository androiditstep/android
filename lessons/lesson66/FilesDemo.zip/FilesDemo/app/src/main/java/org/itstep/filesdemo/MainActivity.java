package org.itstep.filesdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Date;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    public static final String FILE_NAME = "data.txt";
    private static final String TAG = "MainActivity";
    EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);

        File filesDir = getFilesDir();

        File newDir = new File(getFilesDir() + "/directory");
        if(!newDir.exists()) {
            newDir.mkdir();
        }

        File fileToDelete = new File(filesDir, "data");
        if(fileToDelete.exists() && fileToDelete.isFile()) {
            fileToDelete.delete();
        }

        for(File fileName: filesDir.listFiles()) {
            Log.i(TAG, "FilesDir: fileName " + fileName.getAbsolutePath() +
                            " Last Modified: " + new Date(fileName.lastModified()));

        }
        File cacheDir = getCacheDir();
        for(String fileName: cacheDir.list()) {
            Log.i(TAG, "CacheDir: fileName " + fileName );
        }
    }

    public void saveToFile(View view) {
        String text = editText.getText().toString();
        save(text);
    }

    private void save(String text) {
        OutputStream out = null;
        PrintStream printStream = null;
        try {
            out = openFileOutput(FILE_NAME, MODE_APPEND);
            printStream = new PrintStream(out);
            //out.write(text.getBytes());
            printStream.print(text);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void readFromFile(View view) {
        editText.setText(read());
    }

    private String read() {
        InputStream in = null;
        StringBuilder textBuilder = new StringBuilder();
        Scanner scanner;
        try {
            in = openFileInput(FILE_NAME);
            scanner = new Scanner(in);
            String str = scanner.nextLine();
            textBuilder.append(str);
//            byte[] buff = new byte[255];
//            int count = -1;
//            while ((count = in.read(buff, 0, buff.length)) > 0){
//                String str = new String(buff, 0, count);
//                textBuilder.append(str);
//            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return textBuilder.toString();
    }
}
