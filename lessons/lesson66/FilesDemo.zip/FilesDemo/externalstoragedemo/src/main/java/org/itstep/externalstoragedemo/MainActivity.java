package org.itstep.externalstoragedemo;

import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    TextView textView;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);

        imageView = findViewById(R.id.imageView);
        Task task = new Task();
        task.id = 1;
        task.title = "test";
        try {
            OutputStream out = openFileOutput("tasks.dat", MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(out);
            objectOutputStream.writeObject(task);
            out.close();

            InputStream in = openFileInput("tasks.dat");
            ObjectInputStream objectInputStream = new ObjectInputStream(in);
            Task t = (Task) objectInputStream.readObject();
            Log.i(TAG, "task: " + t);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        // Internal storage for application
        /* getFilesDir();
           getCacheDir();
           openFileInput();
           openFileOutput();*/

        String externalStorageState = Environment.getExternalStorageState();
        textView.setText(externalStorageState);
        if(Environment.MEDIA_MOUNTED.equals(externalStorageState)) {
            // Ready to use
            Toast.makeText(this, "external storage mounted", Toast.LENGTH_SHORT).show();

            // External storage for application
            File externalCacheDir = getExternalCacheDir();
            Log.i(TAG, "External cache dir " + externalCacheDir.getAbsolutePath());
            File externalDCIM = getExternalFilesDir(Environment.DIRECTORY_DCIM);
            Log.i(TAG, "External DCIM dir " + externalDCIM);

            // Public directory
            File externalStoragePublicDirectory
                    = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            Log.i(TAG, "Public DCIM dir " + externalStoragePublicDirectory);

            File externalStoragePublicDownload
                    = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            Log.i(TAG, "Download dir " + externalStoragePublicDownload.getAbsolutePath());
            if(externalStoragePublicDownload.listFiles() != null) {
                for (File f : externalStoragePublicDownload.listFiles()) {
                    Log.i(TAG, "File: " + f.getAbsolutePath());
                }
            }

            File externalDir = Environment.getExternalStorageDirectory();

            Log.i(TAG, "External dir: " + externalDir.getAbsolutePath());
            File browserDir = new File(externalDir, "Android/data/com.android.browser/files/Download");
            if(browserDir.listFiles()!=null) {
                for(File f: browserDir.listFiles()) {
                    Log.i(TAG, "img: " + f.getAbsolutePath());
                    imageView.setImageBitmap(BitmapFactory.decodeFile(f.getAbsolutePath()));
                }
            }

        } else {
            Toast.makeText(this, "not ready", Toast.LENGTH_SHORT).show();
        }
    }
}

class Task implements Serializable
{
    int id;
    String title;

    @Override
    public String toString() {
        return "Task{" +
                "id=" + id +
                ", title='" + title + '\'' +
                '}';
    }
}
