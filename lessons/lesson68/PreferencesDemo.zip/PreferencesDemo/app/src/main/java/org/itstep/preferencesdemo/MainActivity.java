package org.itstep.preferencesdemo;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.listener.multi.BaseMultiplePermissionsListener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    public static final String FILE_TXT = "file.txt";
    private static final String TAG = "MainActivity";
    private static final int EXTERNAL_STORAGE_REQUEST_PERMISSION = 1;
    public static final String DEFAULT_NAME = "DefaultName";
    public static final String AUTO_SAVE = "AutoSave";
    public static final String TIME_OFFSET = "TimeOffset";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.i(TAG, "onCreate: activity name " + getLocalClassName());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            String sharedPrefName = PreferenceManager.getDefaultSharedPreferencesName(this);
            Log.i(TAG, "onCreate: shared pref name " + sharedPrefName);
        }
        // получение настроек
        SharedPreferences settings = getPreferences(MODE_PRIVATE);//getSharedPreferences("settings", MODE_PRIVATE);


        // сохранение настроек
        SharedPreferences.Editor edit = settings.edit();
        edit.putString(DEFAULT_NAME, "Filename");
        edit.putBoolean(AUTO_SAVE, true);
        edit.putInt(TIME_OFFSET, 2);
        edit.apply();

//      requestStroragePermission();
        Dexter.withActivity(this)
                .withPermissions(Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                 Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new BaseMultiplePermissionsListener(){
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        writeToExtrernalStorage();
                        readFromExternal();
                    }
                })
                .check();
//        writeToExtrernalStorage();

  //      readFromExternal();
    }

//    private void requestStroragePermission() {
//        if(ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
//            == PackageManager.PERMISSION_GRANTED) {
//            Log.i(TAG, "requestStroragePermission: GRANTED WRITE TO STORAGE");
//            writeToExtrernalStorage();
//            readFromExternal();
//        } else {
//            if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
//                ActivityCompat.requestPermissions(this, new String[]{
//                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
//                            Manifest.permission.READ_EXTERNAL_STORAGE
//                        },
//                        EXTERNAL_STORAGE_REQUEST_PERMISSION);
//            }
//        }
//    }
//
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        //super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if(requestCode == EXTERNAL_STORAGE_REQUEST_PERMISSION) {
//            if(permissions[0].equals(Manifest.permission.WRITE_EXTERNAL_STORAGE)
//                    && permissions[1].equals(Manifest.permission.READ_EXTERNAL_STORAGE)
//                    && grantResults[0] == PackageManager.PERMISSION_GRANTED
//                    && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
//                writeToExtrernalStorage();
//                readFromExternal();
//            }
//        }
//    }

    private void readFromExternal() {
        File externalFilesDir =
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
        InputStream in = null;
        try {
            in = new FileInputStream(externalFilesDir.getAbsoluteFile() + "/" + FILE_TXT);
            byte[] buff = new byte[255];
            int len = in.read(buff);
            String text = new String(buff, 0, len);
            Log.i(TAG, "readFromExtrernalStorage: " + text);
        } catch (IOException e) {
            Log.e(TAG, "writeToExtrernalStorage: ", e);
        }finally {
            if(in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        startActivity(new Intent(this, SettingsActivity.class));
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    private void writeToExtrernalStorage() {
        File externalFilesDir =
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
                               //getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        OutputStream out = null;
        try {
            if(!externalFilesDir.isDirectory()) {
                externalFilesDir.mkdir();
            }
            out = new FileOutputStream(externalFilesDir.getAbsoluteFile() + "/" + FILE_TXT);
            out.write("Hello World".getBytes());
            Log.i(TAG, "writeToExtrernalStorage: writed successfully to " + externalFilesDir.getAbsolutePath());
        } catch (IOException e) {
            Log.e(TAG, "writeToExtrernalStorage: ", e);
        }finally {
            if(out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
