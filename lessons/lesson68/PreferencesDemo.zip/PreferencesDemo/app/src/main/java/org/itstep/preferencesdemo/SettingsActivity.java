package org.itstep.preferencesdemo;

import android.Manifest;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class SettingsActivity extends AppCompatActivity {

    private static final String TAG = "SettingsActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        SharedPreferences settings = getSharedPreferences("settings", MODE_PRIVATE);
        Log.i(TAG, "onCreate: " + settings.getString(MainActivity.DEFAULT_NAME, ""));
        Log.i(TAG, "onCreate: " + settings.getBoolean(MainActivity.AUTO_SAVE, false));
        Log.i(TAG, "onCreate: " + settings.getInt(MainActivity.TIME_OFFSET, 0));
    }
}
