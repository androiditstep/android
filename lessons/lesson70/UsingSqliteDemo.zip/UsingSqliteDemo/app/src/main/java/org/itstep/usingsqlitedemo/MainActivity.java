package org.itstep.usingsqlitedemo;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    ToDoListDbHelper dbHelper;
    ListView lvTodoList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        lvTodoList = findViewById(R.id.lvTodoList);

        dbHelper = new ToDoListDbHelper(this);
        //insertData();
        loadData();
        loadDataToListView();
    }

    private void loadDataToListView() {
        SQLiteDatabase readableDatabase = dbHelper.getReadableDatabase();
        Cursor cursor = readableDatabase.rawQuery("SELECT " + ToDoListDbHelper.Fields._ID + ","
                + ToDoListDbHelper.Fields.TITLE + ","
                + ToDoListDbHelper.Fields.DONE
                + " FROM " + ToDoListDbHelper.TODOLIST_TABLE_NAME, null);
        String[] from = new String[]{
            ToDoListDbHelper.Fields.TITLE,
            ToDoListDbHelper.Fields.DONE
        };
        int[] to = {
            R.id.textViewTitle,
            R.id.tvStatus
        };
        SimpleCursorAdapter cursorAdapter = new SimpleCursorAdapter(this,
                R.layout.item, cursor, from, to, 0);
        lvTodoList.setAdapter(cursorAdapter);
    }

    private void loadData() {
        SQLiteDatabase readableDatabase = dbHelper.getReadableDatabase();
        Cursor cursor = readableDatabase.rawQuery("SELECT " + ToDoListDbHelper.Fields._ID + ","
                                                + ToDoListDbHelper.Fields.TITLE + ","
                                                + ToDoListDbHelper.Fields.DONE
                                                + " FROM " + ToDoListDbHelper.TODOLIST_TABLE_NAME, null);
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String title = cursor.getString(1);
            String done = cursor.getString(2);
            Log.i(TAG, "loadData: " + id + " " + title + " " + done);
        }
        readableDatabase.close();
    }

    private void insertData() {
        SQLiteDatabase writableDatabase = dbHelper.getWritableDatabase();

//        writableDatabase.execSQL("insert into todolist(title) values ('Создать таблицу для задания ToDoList')");
        ContentValues values = new ContentValues();
        values.put(ToDoListDbHelper.Fields.TITLE, "Уйти на перемену");
        writableDatabase.insert(ToDoListDbHelper.TODOLIST_TABLE_NAME, null, values);
        writableDatabase.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
