package org.itstep.usingsqlitedemo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class ToDoListDbHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "todolist.sqlite";
    public static final int DB_VERSION = 2;

    public static final String TODOLIST_TABLE_NAME = "todolist";
    public static final String CATEGORY_TABLE_NAME = "category";

    public final static class Fields {
        public static final String _ID = "_id";
        public static final String TITLE = "title";
        public static final String PRIORITY = "priority";
        public static final String DATE_START = "date_start";
        public static final String DATE_END = "date_end";
        public static final String DONE = "done";
        public static final String NAME = "name";
    }

    public static final String CREATE_TABLE_TODOLIST_1 = "create table if not exists " + TODOLIST_TABLE_NAME +
            "(\n" +
                Fields._ID + " integer primary key autoincrement,\n" +
                Fields.TITLE + " text not null,\n" +
                Fields.PRIORITY + " int default 5,\n" +
                Fields.DATE_START + " text default current_timestamp,\n" +
                Fields.DATE_END + " text,\n" +
                Fields.DONE + " text check(done='not started' or done='in progress' or done='completed') \n" +
                "          default 'not started' not null\n" +
            ");";

    public static final String ALTER_TODOLIST_TABLE_1_2 = "alter table " + TODOLIST_TABLE_NAME +
                                        " add column category_id int references category("+Fields._ID+");";

    public static final String CREATE_TABLE_CATEGORY_2 = "create table " + CATEGORY_TABLE_NAME +
            "(\n" +
                Fields._ID + " integer primary key autoincrement,\n" +
                Fields.NAME + " text not null unique\n" +
            ");";

    private static final String TAG = "ToDoListDbHelper";


    public ToDoListDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i(TAG, "onCreate: table " + CREATE_TABLE_TODOLIST_1);
        db.execSQL(CREATE_TABLE_TODOLIST_1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.i(TAG, "onUpgrade: newVersion " + newVersion);
        if(oldVersion == 1 && newVersion == 2) {
            db.execSQL(CREATE_TABLE_CATEGORY_2);
            db.execSQL(ALTER_TODOLIST_TABLE_1_2);
        }
    }
}
