package org.itstep.contentproviderdemo;

import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import org.itstep.contentproviderdemo.provider.AcademyContentProvider;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        /*ContentValues cv = new ContentValues();
        cv.put(AcademyContentProvider.Fields.NAME, "Вася");
        cv.put(AcademyContentProvider.Fields.EMAIL, "vasja@mail.com");
        getContentResolver().insert(AcademyContentProvider.CONTENT_URI, cv);*/

        String[] projection = {
                AcademyContentProvider.Fields._ID,
                AcademyContentProvider.Fields.NAME,
                AcademyContentProvider.Fields.EMAIL
        };
        Cursor query = getContentResolver().query(AcademyContentProvider.CONTENT_URI, projection, null, null, null);

        int idx[] = {
            query.getColumnIndex(projection[0]),
            query.getColumnIndex(projection[1]),
            query.getColumnIndex(projection[2]),
        };

        while(query.moveToNext()) {
            Log.i(TAG, "onCreate: id " + query.getInt(idx[0]));
            Log.i(TAG, "onCreate: name " + query.getString(idx[1]));
            Log.i(TAG, "onCreate: email " + query.getString(idx[2]));
        }

        /*int id = AcademyContentProvider.uriMatcher.match(AcademyContentProvider.CONTENT_URI);
        Log.i(TAG, AcademyContentProvider.CONTENT_URI + ": " + id); // 1
        Uri uriStudent = Uri.withAppendedPath(AcademyContentProvider.CONTENT_URI, "10");
        id = AcademyContentProvider.uriMatcher.match(uriStudent);
        Log.i(TAG, uriStudent + ": " + id); // 2
        String lastSegment = uriStudent.getLastPathSegment();
        Log.i(TAG, "onCreate: lastSegment: " + lastSegment);*/

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
