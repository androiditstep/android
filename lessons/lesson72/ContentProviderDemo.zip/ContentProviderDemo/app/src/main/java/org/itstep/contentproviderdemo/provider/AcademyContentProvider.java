package org.itstep.contentproviderdemo.provider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.util.Log;

import java.lang.reflect.Field;

public class AcademyContentProvider extends ContentProvider {

    public static final String PROVIDER_NAME = "org.itstep.academy";
    public static final String URI = "content://" + PROVIDER_NAME + "/" + AcademyDbHelper.TABLE_NAME;
    public static final Uri CONTENT_URI = Uri.parse(URI);

    public static final int STUDENT = 1;
    public static final int STUDENT_ID = 2;

    public static final UriMatcher uriMatcher;

    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(PROVIDER_NAME, AcademyDbHelper.TABLE_NAME, STUDENT);
        uriMatcher.addURI(PROVIDER_NAME, AcademyDbHelper.TABLE_NAME + "/#", STUDENT_ID);
    }

    private AcademyDbHelper dbHelper;
    private SQLiteDatabase db;

    public final static class Fields {
        public static final String _ID = "_id";
        public static final String EMAIL = "email";
        public static final String NAME = "name";
    }

    private static class AcademyDbHelper extends SQLiteOpenHelper {

        public static final String DB_NAME = "academy.sqlite";
        public static final int DB_VERSION = 1;

        public static final String TABLE_NAME = "students";



        public static final String CREATE_TABLE = "create table if not exists " + TABLE_NAME +
                "(\n" +
                Fields._ID + " integer primary key autoincrement,\n" +
                Fields.NAME + " text not null,\n" +
                Fields.EMAIL + " text not null unique" +
                ");";

        private static final String TAG = "AcademyDbHelper";

        public AcademyDbHelper(Context context) {
            super(context, DB_NAME, null, DB_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            Log.i(TAG, "onCreate: table " + CREATE_TABLE);
            db.execSQL(CREATE_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.i(TAG, "onUpgrade: newVersion " + newVersion);
        }
    }

    public AcademyContentProvider() {
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // Implement this to handle requests to delete one or more rows.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public String getType(Uri uri) {
        switch (uriMatcher.match(uri)) {
            case STUDENT:
                return "vnd.android.cursor.dir/vnd.itstep.students";
            case STUDENT_ID:
                return "vnd.android.cursor.item/vnd.itstep.students";
            default:
                throw new RuntimeException("Not match");
        }
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        switch (uriMatcher.match(uri))
        {
            case STUDENT: //content://org.itstep.academy/students
                long id = db.insert(AcademyDbHelper.TABLE_NAME, null, values); // 1
                if(id > 0) {
                    Uri newStudentUri = Uri.withAppendedPath(CONTENT_URI, String.valueOf(id)); // content://org.itstep.academy/students/1
                    getContext().getContentResolver().notifyChange(newStudentUri, null); // зафиксировать изменения
                    return newStudentUri;
                }

        }
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public boolean onCreate() {
        dbHelper = new AcademyDbHelper(getContext());
        db = dbHelper.getWritableDatabase();
        return db != null;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
        qb.setTables(AcademyDbHelper.TABLE_NAME);

        switch (uriMatcher.match(uri))
        {
            case STUDENT:
                break;
            case STUDENT_ID:
                String id = uri.getLastPathSegment();
                qb.appendWhere(Fields._ID + "=" + id);
                break;
        }
        Cursor c = qb.query(db, projection, selection, selectionArgs, null, null, sortOrder);
        c.setNotificationUri(getContext().getContentResolver(), uri);
        return c;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        // TODO: Implement this to handle requests to update one or more rows.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
