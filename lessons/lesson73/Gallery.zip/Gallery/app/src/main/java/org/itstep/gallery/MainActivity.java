package org.itstep.gallery;

import android.Manifest;
import android.app.LoaderManager;
import android.content.ContentResolver;
import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.os.Build;
import android.provider.MediaStore;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.GridView;
import android.widget.ImageView;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.single.BasePermissionListener;

import java.util.Date;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    private static final String TAG = "MainActivity";
    private static final int LOAD_ID = 0;
    private GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gridView = findViewById(R.id.gridView);

        Dexter.withActivity(this)
                .withPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new BasePermissionListener(){
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse response) {
                        getAllImages();
                    }
                }).check();


        // ContentProvider: MediaStore.Audio.Media
        // Используя CursorLoader и контент-провадер MediaStore.Audio.Media загрузить данные аудио
        // файлов в ListView через SimpleCursorAdapter
        // Выгружать данные: TITLE, MIME_TYPE, DATE_ADDED, DATA, ARTIST, ALBUM
    }

    private void getAllImages() {
        getLoaderManager().initLoader(LOAD_ID, null, this);
        //syncLoadImage();
    }

    private void syncLoadImage() {
        ContentResolver contentResolver = getContentResolver();
        if(contentResolver != null) {
            String [] columns = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.DESCRIPTION,
                MediaStore.Images.Media.MIME_TYPE,
                MediaStore.Images.Media.DATA
            };

            Cursor c = contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    columns, null, null, MediaStore.Images.Media.DATE_ADDED);
            String[] from = {MediaStore.Images.Media.DATA};
            int[] to = {R.id.imageView};
            SimpleCursorAdapter cursorAdapter = new SimpleCursorAdapter(this,
                    R.layout.image_layout, c, from, to, 0);

            gridView.setAdapter(cursorAdapter);
            while(c.moveToNext()) {
                int id = c.getInt(0);
                long dateAdded = c.getLong(1);
                String displayName = c.getString(2);
                String description = c.getString(3);
                String mimeType = c.getString(4);
                String path = c.getString(5);
                Log.i(TAG, "getAllImages: id = " + id + " dateAdded = " + new Date(dateAdded)
                        + " displayName = " + displayName + " description = " + description
                        + " mimeType = " + mimeType + " path = " + path);
            }
        }
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        String [] columns = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.DESCRIPTION,
                MediaStore.Images.Media.MIME_TYPE,
                MediaStore.Images.Media.DATA
        };
        return new CursorLoader(this, MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                columns, null, null, null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        String[] from = {MediaStore.Images.Media.DATA};
        int[] to = {R.id.imageView};
        SimpleCursorAdapter cursorAdapter = new SimpleCursorAdapter(this,
                R.layout.image_layout, data, from, to, 0);

        gridView.setAdapter(cursorAdapter);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        gridView.setAdapter(null);
    }
}
