package org.itstep.multithreads;

import android.content.Context;
import android.graphics.Canvas;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    ProgressBar progressBar;
    private Button button;
    private Thread thread;

    private int number = 100_000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);
        button = findViewById(R.id.button);

        concurencyRaceDemo();
    }

    private synchronized void incrementNumber() {
        number++;
    }

    private synchronized void decrementNumber() {
        number--;
    }

    private void concurencyRaceDemo() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                //number++;
                for (int i = 0; i < 100_000; i++) {
                    incrementNumber();
                }
                Log.i(TAG, "run: " + number);
            }
        }).start();
        new Thread(new Runnable() {
            @Override
            public void run() {
                //number--;
                for (int i = 0; i < 100_000; i++) {
                    decrementNumber();
                }
                Log.i(TAG, "run: " + number);
            }
        }).start();
    }


    public void goProgress(View view) {
        Log.i(TAG, "goProgress: " + Thread.currentThread().getName());
        class LocalThread implements Runnable {
            @Override
            public void run() {
                boolean interrupted = false;
                int count = 0;
                for (int i = 0; i < 100; i++) {
                    count += i;
                    Log.i(TAG, "run: " + Thread.currentThread().getName());
                    Log.i(TAG, "isInterrupted: " + Thread.interrupted());
                    final int j = i + 1;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.i(TAG, "run on post method: " + Thread.currentThread().getName());
                            progressBar.setProgress(j);
                            button.setText(String.valueOf(progressBar.getProgress()));
                        }
                    });

                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) { // если для этого потока был вызван метод interrupt(), то...
                        e.printStackTrace();
                        interrupted = true;
                        break; // прекратить наш цикл
                    }
                    if (Thread.interrupted()) {
                        break;
                    }
                }

                if (!interrupted) { // если не прерывался поток, то...
                    final int finalCount = count;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            setCalcResult(finalCount); // вернуть результат
                        }
                    });
                }
                thread = null;
            }
        }

        if (thread != null && thread.isAlive()) {
            thread.interrupt(); // прервать работу потока
        } else {
            thread = new Thread(new LocalThread(), "Worker Thread");
            thread.start();
        }
    }

    private void setCalcResult(int finalCount) {
        button.setText(String.valueOf(finalCount));
    }
}

class MyView extends View {

    public MyView(Context context) {
        super(context);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }
}
