package org.itstep.bitcoinrate;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private Handler loaderHandler;
    public static final String BTC_RATE_URL = "https://api.darksky.net/forecast/00ce670b3742a599df4c805e00fb6876/48.4695846,35.0133742?lang=ru&units=si&exclude=minutely,hourly,daily,alerts,flags";
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);

        new Thread(new Runnable() {
            @Override
            public void run() {
                Looper.prepare();
                loaderHandler = new Handler(Looper.myLooper());
                Looper.loop();
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        loaderHandler.getLooper().quit();
    }

    public void getBtcRate(View view) {
        loaderHandler.post(new Runnable() {
            @Override
            public void run() {
                Log.i(TAG, "run: " + Thread.currentThread().getName());
                try {
                    URL url = new URL(BTC_RATE_URL);
                    BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
                    String line;
                    StringBuilder stringBuilder = new StringBuilder();
                    while((line = reader.readLine()) != null) {
                        stringBuilder.append(line);
                    }
                    String json = stringBuilder.toString();
                    Log.i(TAG, "json: " + json);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
