package org.itstep.handlerthreaddemo;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static TextView textView;

    private Handler uiHandler;
    private Handler threadHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);
        //textView.setText("");
        //deadlock();
        //int processors = Runtime.getRuntime().availableProcessors();
        //updateUI("Processors: " + processors + "\n");
        uiHandler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                Log.i(TAG, "handleMessage: ThreadName = " + Thread.currentThread().getName());
                updateUI(msg.obj.toString());
                return true;
            }
        });

        new Thread(new Runnable() {
            private Handler.Callback callback = new Handler.Callback() {
                @Override
                public boolean handleMessage(Message msg) {
                    Log.i(TAG, "handleMessage: CallbackThread = " + Thread.currentThread().getName());
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    uiHandler.sendMessage(Message.obtain(msg));
                    return true;
                }
            };

            @Override
            public void run() {
                Log.i(TAG, "run: Start thread " + Thread.currentThread().getName());
                Looper.prepare();
                threadHandler = new Handler(Looper.myLooper(), callback);
                Looper.loop();
                Log.i(TAG, "run: End thread " + Thread.currentThread().getName());
//                try {
//                    Thread.sleep(3000);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//                Message msg = new Message();
//                msg.obj = "Hello from " + Thread.currentThread().getName();
//                uiHandler.sendMessage(msg);
            }
        }).start();
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        threadHandler.getLooper().quit();
    }
    private void deadlock() {
        final A a = new A();
        final B b = new B();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    a.hello(b);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    b.hello(a);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    static class A  {
        //int data;
        AtomicInteger atomicData = new AtomicInteger(0);
        void hello(B b) throws InterruptedException {
            updateUI("Start hello B\n");
            //synchronized (b)
            {
                Thread.sleep(100);
                b.atomicData.set(1);
                //b.data = 1;
                updateUI("Update a.data\n");
                //synchronized (this)
                {
                    this.atomicData.addAndGet(1);
                    //this.data = b.data + 1;
                }
                //updateUI("This line is newer shown");
                updateUI("Result a.data = " + this.atomicData.get() + "\n");
            }
        }
    }

    public void sendMessageToHandler(View view){
        Message msg = new Message();
        msg.obj = "Hello Thread from UI";
        threadHandler.sendMessage(msg);
    }

    private static void updateUI(final String text) {
        textView.post(new Runnable() {
            @Override
            public void run() {
                textView.append(text + "\n");
            }
        });
    }



    static class B  {
        //int data;
        AtomicInteger atomicData = new AtomicInteger(0);
        void hello(A a) throws InterruptedException {
            updateUI("Start hello A\n");
            //synchronized (a)
            {
                Thread.sleep(100);
                a.atomicData.set(1);
                //a.data = 1;
                updateUI("Update b.data\n");
                //synchronized (this)
                {
                    this.atomicData.addAndGet(1);
                    //this.data = a.data+1;
                }
                //updateUI("This line is newer shown");
                updateUI("Result b.data = " + this.atomicData.get() + "\n");
            }
        }
    }
}
