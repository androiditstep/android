package org.itstep.asynctaskdemo;

import android.os.AsyncTask;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    HandlerThread handlerThread;

    DemoAsyncTask asyncTask;

    TextView textView;

    ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //handlerThreadDemo();
        textView = findViewById(R.id.textView);

        executorService = Executors.newCachedThreadPool();
                          // Executors.newFixedThreadPool(2);
                          // Executors.newSingleThreadExecutor();
        for (int i = 0; i < 4; i++) {
            final int finalI = i;
            Future<?> res = executorService.submit(new Runnable() {
                @Override
                public void run() {
                    for (int r = 0; r < 10; r++) {
                        try {
                            Thread.sleep(300);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        Log.i(TAG, r + ") " + Thread.currentThread().getName());
                    }
                }
            });
//            try {
//                res.get(); // Блокирует текущий поток до тех пор, пока задача не будет заверешена
//            } catch (InterruptedException | ExecutionException e) {
//                e.printStackTrace();
//            }
        }
    }

    public void executorStart(View view) {
        asyncTask = new DemoAsyncTask();
        //asyncTask.execute(1, 100, 100);
        asyncTask.executeOnExecutor(executorService, 1, 100, 100);
    }

    class DemoAsyncTask extends AsyncTask<Integer, Integer, Integer> {

        @Override
        protected void onPreExecute() {
            textView.setText("");
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            textView.setText(String.valueOf(values[0]));
        }

        @Override
        protected Integer doInBackground(Integer... args) {
            if (args.length < 3) {
                throw new RuntimeException("Arguments should be at least 3");
            }
            Integer from = args[0];
            Integer to = args[1];
            Integer timeout = args[2];

            int count = 0;

            for (int i = from; i < to; i++) {
                try {
                    Thread.sleep(timeout);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                count += i;
                publishProgress(i);
            }

            return count;
        }

        @Override
        protected void onPostExecute(Integer count) {
            textView.setText("Result: " + count);
        }
    }

    private void handlerThreadDemo() {
        handlerThread = new HandlerThread("Download Thread") {
            @Override
            protected void onLooperPrepared() {
                try {
                    URL url = new URL("http://google.com");
                    InputStream inputStream = url.openStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
                    String line = null;
                    while ((line = br.readLine()) != null) {
                        Log.i(TAG, "onLooperPrepared: " + line);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        handlerThread.start();

        new Handler(handlerThread.getLooper()).post(new Runnable() {
            @Override
            public void run() {
                // run on Download Thread
                Log.i(TAG, "run: " + Thread.currentThread().getName());
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handlerThread != null) {
            handlerThread.quit();
        }
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdownNow();
        }
    }
}
