package org.itstep.networkdemo.http;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;

public class RawHttpRequest {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("flibusta.is", 80);
        BufferedReader rdr =
                new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintStream wtr =
                new PrintStream(socket.getOutputStream());

        wtr.print("GET /sfgtsa HTTP/1.1\r\n");
        wtr.print("Host: flibusta.is\r\n");
        wtr.print("Connection: close\r\n");
        wtr.print("\r\n");

        String answer;
        while((answer = rdr.readLine()) != null) {
            System.out.println("Server: " +answer);
        }
        socket.close();
    }
}
