package org.itstep.networkdemo.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;

public class ClientDemo {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("127.0.0.1", 10_000);
        BufferedReader rdr =
                new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintStream wtr =
                new PrintStream(socket.getOutputStream());

        wtr.println("Hello Server");
        String answer = rdr.readLine();
        System.out.println("Server: " +answer);
        socket.close();
    }
}
