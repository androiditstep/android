package org.itstep.networkdemo.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class UdpReceiver {
    public static void main(String[] args) throws IOException {
        DatagramSocket receiver = new DatagramSocket(10_001);
        DatagramPacket packet = new DatagramPacket(new byte[256], 0, 256);
        while(true) {
            receiver.receive(packet);
            String time = new String(packet.getData(), packet.getOffset(), packet.getLength());
            System.out.println("Server time: " + time);
        }
    }
}
