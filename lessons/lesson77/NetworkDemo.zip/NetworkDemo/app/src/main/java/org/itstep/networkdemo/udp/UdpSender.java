package org.itstep.networkdemo.udp;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.time.LocalDateTime;

public class UdpSender {
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void main(String[] args) throws IOException, InterruptedException {
        DatagramSocket sender = new DatagramSocket();
        while(true) {
            String dateTime = "Hi android developer";LocalDateTime.now().toString();
            byte[] buff = dateTime.getBytes();
            DatagramPacket packet = new DatagramPacket(buff, 0,
                    buff.length, InetAddress.getByName("10.2.105.255"), 10_001);
            sender.send(packet);
            System.out.println(dateTime);
            Thread.sleep(1000);
        }
    }
}
