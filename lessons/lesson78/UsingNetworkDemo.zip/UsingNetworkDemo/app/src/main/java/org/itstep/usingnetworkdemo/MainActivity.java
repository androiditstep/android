package org.itstep.usingnetworkdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Iterator;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    static String json = "{\n" +
            "   \"firstName\": \"Иван\",\n" +
            "   \"lastName\": \"Иванов\",\n" +
            "   \"address\": {\n" +
            "       \"streetAddress\": \"Московское ш., 101, кв.101\",\n" +
            "       \"city\": \"Ленинград\",\n" +
            "       \"postalCode\": \"101101\"\n" +
            "   },\n" +
            "   \"phoneNumbers\": [\n" +
            "       \"812 123-1234\",\n" +
            "       \"916 123-4567\"\n" +
            "   ]\n" +
            "}";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        WebView webView = findViewById(R.id.browser);
        //webView.loadData("<h1>Hello WebView</h1><div><a href='http://itstep.dp.ua'>Click me</a></div>","text/html", "utf-8");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("https://itstep.dp.ua");

        //demo();

        OkHttpClient httpClient = new OkHttpClient();
        final Request request = new Request.Builder()
                                     .header("Accept", "application/json")
                                     .url("http://resources.finance.ua/ru/public/currency-cash.json")
                                     .build();
        Call call = httpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "onFailure: ", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if(response.isSuccessful()) {
                    Log.i(TAG, "onResponse: " + response.body().string());
                }
            }
        });
    }

    private void demo() {
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(json);
            for (Iterator<String> it = jsonObject.keys(); it.hasNext(); ) {
                String key = it.next();
                System.out.println(key);
            }
            String firstName = jsonObject.getString("firstName");
            String lastName = jsonObject.getString("lastName");
            JSONObject address = jsonObject.getJSONObject("address");
            JSONArray phones = jsonObject.getJSONArray("phoneNumbers");
            System.out.println("firstName = " + firstName);
            System.out.println("lastName = " + lastName);
            if(jsonObject.has("USD")) {

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
