package org.itstep.usingapi;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.itstep.usingapi.api.AllTodoList;
import org.itstep.usingapi.api.ToDo;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    public static final String baseUrl = "http://10.2.105.10:8081/api/v1/todolist/";
    private static final String TAG = "MainActivity";

    OkHttpClient client;
    boolean online;
    Gson gson;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        client = new OkHttpClient();
        gson = new GsonBuilder().create();

        String json = "{\"name\": \"Вася\", \"age\": 21}";
        Log.i(TAG, "onCreate: json = " + json);
        Person person = gson.fromJson(json, Person.class);
        Log.i(TAG, "onCreate: person = " + person);
        String str = gson.toJson(person);

        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        if(activeNetworkInfo == null) {
            Toast.makeText(this, "No active network", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, activeNetworkInfo.toString(), Toast.LENGTH_LONG).show();
            online = true;
            getTodoList();
            newTodoItem();
        }

        // 1. Нажав на кнопку Read считать данные с сервера для задачи с заданным id, отобразить
        // задачу в активности
        // 2. Нажав на кнопку Update - обновить задачу на сервере по заданному id
    }

    private void newTodoItem() {
        ToDo toDo = new ToDo("Изучить Gson", "Полезная библиотека для работы с json", "MEDIUM", false);
        RequestBody todoBody = RequestBody.create(MediaType.parse("application/json"),
                gson.toJson(toDo));
        Request request = new Request.Builder()
                .url(baseUrl)
                .post(todoBody)
                .build();
        client.newCall(request).enqueue(null);
    }

    private void getTodoList() {
        final Request request = new Request.Builder()
                .url(baseUrl)
                .get() // GET
                .build();

        client.newCall(request)
                .enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        Toast.makeText(MainActivity.this, "Fail: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        String json = response.body().string();
                        Log.i(TAG, "onResponse: json: " + json);
                        AllTodoList allTodoList = gson.fromJson(json, AllTodoList.class);
                        for(ToDo todo: allTodoList.getEmbedded().getToDos()) {
                            Log.i(TAG, "onResponse: " + todo);
                        }
                    }
                });
    }
}
