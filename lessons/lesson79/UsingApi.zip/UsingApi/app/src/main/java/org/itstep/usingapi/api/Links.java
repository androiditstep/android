
package org.itstep.usingapi.api;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Links {

    @SerializedName("self")
    @Expose
    private Self self;
    @SerializedName("toDo")
    @Expose
    private ToDo_ toDo;

    public Self getSelf() {
        return self;
    }

    public void setSelf(Self self) {
        this.self = self;
    }

    public ToDo_ getToDo() {
        return toDo;
    }

    public void setToDo(ToDo_ toDo) {
        this.toDo = toDo;
    }

}
