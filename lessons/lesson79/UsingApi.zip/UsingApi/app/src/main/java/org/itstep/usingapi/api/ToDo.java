
package org.itstep.usingapi.api;

import android.net.Uri;
import android.net.UrlQuerySanitizer;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ToDo {

    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("created")
    @Expose
    private String created;
    @SerializedName("lastUpdate")
    @Expose
    private String lastUpdate;
    @SerializedName("priority")
    @Expose
    private String priority;
    @SerializedName("done")
    @Expose
    private Boolean done;
    @SerializedName("_links")
    @Expose
    private Links links;

    public ToDo() {
    }

    public ToDo(String title, String description, String priority, Boolean done) {
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.done = done;
    }

    public String getId() {
        String id = null;
        if(links != null) {
            if(links.getSelf() != null) {
                Self self = links.getSelf();
                Uri uri = Uri.parse(self.getHref());
                id = uri.getLastPathSegment();
            }
        }
        return null;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(String lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public Boolean getDone() {
        return done;
    }

    public void setDone(Boolean done) {
        this.done = done;
    }

    public Links getLinks() {
        return links;
    }

    public void setLinks(Links links) {
        this.links = links;
    }

    @Override
    public String toString() {
        return "ToDo{" +
                "title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", created='" + created + '\'' +
                ", lastUpdate='" + lastUpdate + '\'' +
                ", priority='" + priority + '\'' +
                ", done=" + done +
                '}';
    }
}
