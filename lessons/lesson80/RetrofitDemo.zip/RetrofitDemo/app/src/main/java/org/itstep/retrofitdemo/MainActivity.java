package org.itstep.retrofitdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import org.itstep.retrofitdemo.api.github.GithubApi;
import org.itstep.retrofitdemo.api.github.Repo;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    GithubApi api;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        Задание:
//
//        Используя Retrofit и Picaso загрузить и отобразить в активность изображения по заданным тегам
//        с сайта flickr.com
//
//        Конечаня точка:
//        https://api.flickr.com/services/feeds/photos_public.gne?format=json&nojsoncallback=true
//
//
//## Полезные ссылки
//
//* [Picaso](https://square.github.io/picasso)

        initApi();
    }

    private void initApi() {
        api = new Retrofit.Builder()
                .baseUrl("https://api.github.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(GithubApi.class);

        api.listRepoByUser("maxchv", "pushed")
                .enqueue(new Callback<List<Repo>>() {
                    @Override
                    public void onResponse(Call<List<Repo>> call, Response<List<Repo>> response) {
                        if(response.isSuccessful()) {
                            List<Repo> repos = response.body();
                            for(Repo r : repos) {
                                Log.i(TAG, "onResponse: " + r);
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Repo>> call, Throwable t) {

                    }
                });
    }
}
