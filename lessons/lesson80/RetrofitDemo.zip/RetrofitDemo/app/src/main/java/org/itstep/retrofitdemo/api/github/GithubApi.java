package org.itstep.retrofitdemo.api.github;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.QueryName;

public interface GithubApi {

    @GET("users/{user}/repos")
    Call<List<Repo>> listRepoByUser(@Path("user") String user);

    @GET("users/{user}/repos")
    Call<List<Repo>> listRepoByUser(@Path("user") String user,
                                    @Query("sort") String sort);
    // listRepoByUser("maxchv", "pushed") -> GET /users/maxchv/repos?sort=pushed

    @POST("/path/to/create/repository")
    Call<Void> create(@Body Repo repo);
}
