package org.itstep.firebasedemo;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.PagerTitleStrip;
import android.view.View;

class SimplePagerAdapter extends FragmentPagerAdapter{
    String[] data;

    public SimplePagerAdapter(FragmentManager fm, String[] data) {
        super(fm);
        this.data = data;
    }

    @Override
    public int getCount() {
        return data.length;
    }


    @Override
    public Fragment getItem(int position) {
        return SimpleFragment.newInstance(data[position]);
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return String.format("Item %d", position);
    }
}
