package org.itstep.mediademo;

import android.Manifest;
import android.content.Context;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.single.BasePermissionListener;

import java.io.IOException;

public class AudioRecordActivity extends AppCompatActivity {

    private static final String TAG = "AudioRecordActivity";
    boolean isRecord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_record);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        final MediaRecorder mediaRecorder = new MediaRecorder();
        final FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        Context cxt = getApplicationContext();
        final String absolutePath = cxt.getFilesDir().getAbsolutePath();
        Log.i(TAG, "onCreate: path " + absolutePath);

        fab.setEnabled(false);
        Dexter.withActivity(this)
                .withPermission(Manifest.permission.RECORD_AUDIO)
                .withListener(new BasePermissionListener(){
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse response) {
                        super.onPermissionGranted(response);
                        mediaRecorder.setOutputFile(absolutePath + "/audio.3gp");
                        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                        try {
                            mediaRecorder.prepare();
                            fab.setEnabled(true);
                            Log.i(TAG, "onPermissionGranted: enabled");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).check();


        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!isRecord) {
                    Log.i(TAG, "onClick: start");
                    mediaRecorder.start();
                    isRecord = true;
                } else {
                    Log.i(TAG, "onClick: stop");
                    mediaRecorder.stop();
                    isRecord = false;
                }
            }
        });
    }

}
