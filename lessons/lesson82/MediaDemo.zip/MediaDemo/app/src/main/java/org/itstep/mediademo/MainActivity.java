package org.itstep.mediademo;

import android.app.Activity;
import android.content.res.AssetManager;
import android.net.Uri;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    VideoView mVideoView;
    FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mVideoView = findViewById(R.id.videoView);

        fab = findViewById(R.id.floatingActionButton);

        final MediaController mc = new MediaController(this);
        mc.setAnchorView(mVideoView);
        mVideoView.setMediaController(mc);
        mVideoView.setVideoPath("http://10.2.105.10/movie.mp4");

        mVideoView.postDelayed(new Runnable() {
            @Override
            public void run() {
                mc.show(10000);
            }
        }, 1000);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "onClick: ");
                //String path = "android.resource://" + getPackageName() + "/" + R.raw.mov_bbb;
                //mVideoView.setVideoURI(Uri.parse(path));

                mVideoView.start();
            }
        });
    }
}
