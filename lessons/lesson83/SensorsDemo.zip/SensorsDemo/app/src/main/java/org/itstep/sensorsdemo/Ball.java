package org.itstep.sensorsdemo;


import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.display.DisplayManager;
import android.support.v7.widget.AppCompatImageView;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ViewGroup;

public class Ball extends AppCompatImageView implements SensorEventListener {

    private static final String TAG = "Ball";

    private SensorManager sensorManager;
    private DisplayManager displayManager;
    private Sensor accelerometer;
    private ViewGroup.LayoutParams layoutParams;

    public Ball(Context context) {
        this(context, null);
    }

    public Ball(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public Ball(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        Log.i(TAG, "onAttachedToWindow: ");
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if(accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
        }
        layoutParams = getLayoutParams();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Log.i(TAG, "onDetachedFromWindow: ");
        if(accelerometer != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if(accelerometer == event.sensor) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];
            Log.i(TAG, String.format("onSensorChanged: x = %g, y = %g, z = %g\n", x, y, z));
            setX(getX() - x * .5f);
            setY(getY() + y * .5f);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
