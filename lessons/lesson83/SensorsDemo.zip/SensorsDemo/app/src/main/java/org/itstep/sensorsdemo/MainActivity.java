package org.itstep.sensorsdemo;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final String TAG = "MainActivity";
    private SensorManager sm;
    ScheduledExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        List<Sensor> sensorList = sm.getSensorList(Sensor.TYPE_ALL);
        for(Sensor sensor: sensorList) {
            Log.i(TAG, "onCreate: " + sensor);
        }

        executorService = Executors.newScheduledThreadPool(4);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Sensor acceleration = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if(acceleration != null) {
            Log.i(TAG, "onCreate: default accelerometer " + acceleration);
            sm.registerListener(this, acceleration, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        sm.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
//        Log.i(TAG, "onSensorChanged: ");
        if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];
            //Log.i(TAG, String.format("onSensorChanged: x = %g, y = %g, z = %g\n", x, y, z));
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        //Log.i(TAG, "onAccuracyChanged: " + accuracy);
    }
}
