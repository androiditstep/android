package org.itstep.googlemapdemo;

import android.Manifest;
import android.annotation.SuppressLint;
import android.location.Location;
import android.os.Bundle;
import android.os.HandlerThread;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.PlaceLikelihood;
import com.google.android.libraries.places.api.net.FindCurrentPlaceRequest;
import com.google.android.libraries.places.api.net.FindCurrentPlaceResponse;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.single.BasePermissionListener;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener, GoogleApiClient.ConnectionCallbacks {

    private static final String TAG = "MainActivity";
    private GoogleApiClient mGoogleApiClient;
    private TextView tvLong;
    private TextView tvLat;
    private HandlerThread handlerThread;

    private PlacesClient placesClient;

    LocationCallback locationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            Log.i(TAG, "onLocationResult: " + locationResult);
            Location lastLocation = locationResult.getLastLocation();
            showLocation(lastLocation);
        }

        @Override
        public void onLocationAvailability(LocationAvailability locationAvailability) {
            Log.i(TAG, "onLocationAvailability: " + locationAvailability);
        }
    };

    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvLong = findViewById(R.id.tv_longitude);
        tvLat = findViewById(R.id.tv_latitude);

        handlerThread = new HandlerThread("Location handler");

        Places.initialize(this, getResources().getString(R.string.google_maps_key));

        placesClient = Places.createClient(this);

        placesClient.findCurrentPlace(FindCurrentPlaceRequest.builder(Arrays.asList(Place.Field.ADDRESS, Place.Field.LAT_LNG)).build())
                .addOnSuccessListener(new OnSuccessListener<FindCurrentPlaceResponse>() {
                    @Override
                    public void onSuccess(FindCurrentPlaceResponse findCurrentPlaceResponse) {
                        for(PlaceLikelihood pl : findCurrentPlaceResponse.getPlaceLikelihoods()) {
                            Log.i(TAG, "onSuccess: " + pl.getLikelihood() + ": " + pl.getPlace().getAddress());
                        }
                    }
                });

        Dexter.withActivity(this)
                .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                .withListener(new BasePermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse response) {
                        mGoogleApiClient = new GoogleApiClient.Builder(MainActivity.this)
                                .enableAutoManage(MainActivity.this, MainActivity.this)
                                .addConnectionCallbacks(MainActivity.this)
                                .addApi(LocationServices.API)       // ширату и долготу
                                //.addApi(Places.GEO_DATA_API)        // адрес
                                //.addApi(Places.PLACE_DETECTION_API) // адрес
                                .build();
                        mGoogleApiClient.connect();

                    }
                })
                .check();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Toast.makeText(this, connectionResult.getErrorMessage(), Toast.LENGTH_SHORT).show();
        Log.e(TAG, "onConnectionFailed: " + connectionResult.getErrorMessage());
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onConnected(@Nullable Bundle bundle) {
        Log.i(TAG, "onConnected: ");

        // success
//        getLast();
//        LocationServices.getFusedLocationProviderClient(this)
//                .requestLocationUpdates(LocationRequest.create()
//                                .setInterval(3000)
//                                .setFastestInterval(3000)
//                                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY),
//                        locationCallback, handlerThread.getLooper());
    }

    @Override
    protected void onStop() {
        super.onStop();
//        LocationServices.getFusedLocationProviderClient(this)
//                .removeLocationUpdates(locationCallback);
    }

    @SuppressLint("MissingPermission")
    private void getLast() {
        LocationServices.getFusedLocationProviderClient(this)
                .getLastLocation()
                .addOnSuccessListener(new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        showLocation(location);
                    }
                });
    }

    private void showLocation(final Location location) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (location != null) {
                    tvLat.setText(String.valueOf(location.getLatitude()));
                    tvLong.setText(String.valueOf(location.getLongitude()));
                }
            }
        });
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.i(TAG, "onConnectionSuspended: ");
    }
}
